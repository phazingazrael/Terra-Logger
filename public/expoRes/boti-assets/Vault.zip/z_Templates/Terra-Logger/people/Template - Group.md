---
BANNER: "[[Group-Banner.jpg|100]]"
NoteIcon: Group
Name:
Pronounced:
Aliases:
HQ:
AssociatedReligion:
Alignment:
Type:
Location:
tags:
---

> [!infobox]
> # `=this.Name`
> **Pronounced:** "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Type** | `=this.Type` |
> **Alignment** | `=this.Alignment` |
> **Base of Operations** | `=this.HQ` |
> **Location** | `=this.Location` |
> **Associated Religion** | `=this.AssociatedReligion` |

# `=this.Name`

> [!overview]- Overview  
Brief description of the organization — its purpose, influence, and reputation within the world.

> [!groups]- Structure & Membership  
Explain how the group is organized: ranks, internal factions, command hierarchy, or membership requirements.

> [!culture]- Doctrine & Customs  
Ideals, codes of conduct, rituals, recruitment methods, and cultural norms that define the group’s identity.

> [!settlements]- Bases & Locations  
List known outposts, headquarters, or key facilities associated with the group.  
`=this.HQ`

> [!landmarks]- Landmarks
> ```base
> filters:
>   and:
>     - file.inFolder("World/08. Landmarks")
>     - and:
>         - Groups.contains(this.Name)
> views:
>   - type: table
>     name: Table
>     limit: 50
>     order:
>       - file.name
>       - Name
>       - Pronounced
>       - Country
>       - Type
>       - Owners
>       - Staff
>       - tags
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!pois]- Points of Interest
> ```base
> filters:
>   and:
>     - file.inFolder("World/09. Points of Interest")
>     - and:
>         - Groups.contains(this.Name)
> views:
>   - type: table
>     name: Table
>     limit: 50
>     order:
>       - file.name
>       - Name
>       - Category
>       - Type
>       - Features
>       - Owner
>       - Established
>       - Groups
>       - ParentArea
>       - Secrets
>       - Services
>       - tags
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!shops]- Shops
> ```base
> filters:
>   and:
>     - file.inFolder("World/10. Shops & Services")
>     - and:
>         - Groups.contains(this.Name)
> views:
>   - type: table
>     name: Table
>     limit: 50
>     order:
>       - file.name
>       - Name
>       - AffiliatedGroup
>       - Type
>       - Location
>       - Owners
>       - Staff
>       - Pronounced
>       - tags
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!characters]- NPC's
> ```base
> filters:
>   and:
>     - file.inFolder("World/13. NPCs")
>     - and:
>         - Groups.contains(this.Name)
> views:
>   - type: table
>     name: Table
>     limit: 50
>     order:
>       - file.name
>       - Name
>       - Pronounced
>       - Pronouns
>       - Occupation
>       - Location
>       - Gender
>       - Condition
>       - Alignment
>       - Ancestry
>       - OwnedLocations
>       - AssociatedGroup
>       - AssociatedReligion
>       - Heritage
>       - Sexuality
>       - tags
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!Rumors]- Reputation & Relations  
Public opinion, rumors, alliances, rivalries, and political or religious relationships.

> [!story]- History  
Founding, milestones, schisms, or legendary events in the group’s past.

> [!Secrets]- Hidden Details  
GM-only information: secret agendas, concealed affiliations, or internal betrayals.

> [!Notes]- Notes  
Plot hooks, adventure seeds, or miscellaneous notes related to the group.
