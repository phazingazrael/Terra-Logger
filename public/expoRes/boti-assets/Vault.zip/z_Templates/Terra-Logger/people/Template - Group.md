---
BANNER: "[[Group-Banner.jpg|100]]"
Name:
Pronounced:
Aliases:
HQ:
AssociatedReligion:
Alignment:
Type:
Location:
tags:
---

> [!infobox]
> # `=this.Name`
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Basic Information
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Base of Operations** | `=this.HQ` |
> **Associated Religion** | `=this.AssociatedReligion` |
> **Alignment** | `=this.Alignment` |
> **Type** | `=this.Type` |

# **`=this.Name`**
> [!overview]- Overview
TBD

> [!settlements]- Locations
> `=this.location`

> [!landmarks]- Landmarks
> [[🏰 Landmark Database|🏰Add New Landmark]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Group(s)"
WHERE contains(AffiliatedGroup, this.Name) AND contains(NoteIcon, "Landmark")
SORT file.name ASC

> [!pois]- Points of Interest
> [[❓ POI Database|📝Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Group(s)"
WHERE contains(AffiliatedGroup, this.Name) AND contains(NoteIcon, "POI")
SORT file.name ASC

> [!shops]- Shops
> [[💲 Shop & Service Database|📝Add New Shop/Service]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Group(s)"
WHERE contains(AffiliatedGroup, this.Name) AND contains(NoteIcon, "Shop")
SORT file.name ASC

> [!characters]- Characters
> [[👨‍👩‍👧‍👦 NPC Database| 📝Add New NPC]]
> ```dataview
table Pronouns, join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Group(s)", join(link(AssociatedReligion), ", ") AS "Religion(s)"
WHERE contains(AssociatedGroup, this.Name) AND contains(NoteIcon, "Character") AND !contains(Condition, "Dead")
SORT file.name ASC

## Culture
### Mission


### Conduct


### Recruitment & Training


### Ranks


### Uniforms & Equipment


## Acquaintances
### Allies:


### Rivals:


### Contacts:


## History


## Notes
### Plot Hooks


### Hidden Details


### General Notes

