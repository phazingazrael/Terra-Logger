---
BANNER: "[[Player-Banner.jpg|200]]"
Name:
Gender:
Level:
Class:
Subclass:
Background:
Alignment:
Deity:
Size:
STR:
DEX:
CON:
INT:
WIS:
CHA:
AC:
HP:
Initiative:
Perception:
Speed:
Speeds: []
Ancestry:
Heritage:
Condition:
Occupation:
Aliases:
AssociatedGroup:
AssociatedReligion:
Pronouns:
PlayedBy:
Party:
Location:
tags:
---

> [!infobox]
> # `=this.Name` (`=this.Pronouns`)
> **Played By**  `=this.PlayedBy`
> ![[PlaceholderImage.png]]
> ## [Character Sheet](url or file)
> ###### Bio
> Type |  Stat |
> ---|---|
> **Ancestry** | `=this.Ancestry` |
> **Heritage** | `=this.Heritage` |
> **Gender** | `=this.Gender` |
> **Condition** | `=this.Condition` |
> ###### Info
> Type |  Stat |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Occupations** | `=this.Occupation` |
> **Groups** | `=this.AssociatedGroup` |
> **Religions** | `=this.AssociatedReligion` |
> **Location** | `=this.Location` |

# **`=this.Name`**
## Goals
### Short-term


### Long-term


## Ideals
### Loves


### Hates


## Traits
### Perks


### Flaws


## History
### Birth Location


### What was their childhood like growing up?


### Did they have a job before adventuring?


### What has happened between leaving home and the present day?


### What made them leave and what keeps them going?


### Do they know any of the party members before the start of the campaign?


### Do you follow a God, if so why?


## Notable Acquaintances
### Family


### Friends


### Rivals


## Events


## DM Notes
### Additional Notes From Players 


### Hidden Details


### Notes

