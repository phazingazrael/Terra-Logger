---
BANNER: "[[Player-Banner.jpg|200]]"
NoteIcon: Player
Name:
Pronouns:
PlayedBy:
Gender:
Level:
Class:
Subclass:
Background:
Alignment:
Deity:
Size:
STR:
DEX:
CON:
INT:
WIS:
CHA:
AC:
HP:
Initiative:
Perception:
Speed:
Speeds: []
Ancestry:
Heritage:
Condition:
Occupation:
Aliases:
AssociatedGroup:
AssociatedReligion:
Party:
Location:
tags:
---

> [!infobox]
> # `=this.Name` (`=this.Pronouns`)
> **Played By:** `=this.PlayedBy`
> ![[PlaceholderImage.png]]
> ###### Core Stats
>  |
> ---|---|
> **Level** | `=this.Level` |
> **Class** | `=this.Class` |
> **Subclass** | `=this.Subclass` |
> **Background** | `=this.Background` |
> **Alignment** | `=this.Alignment` |
> **Deity** | `=this.Deity` |
> **AC / HP** | `=this.AC` / `=this.HP` |
> **Speed(s)** | `=join(this.Speeds, ", ")` |
> **Initiative** | `=this.Initiative` |
> **Perception** | `=this.Perception` |
> ###### Abilities
>  |
> ---|---|
> **STR** | `=this.STR` |
> **DEX** | `=this.DEX` |
> **CON** | `=this.CON` |
> **INT** | `=this.INT` |
> **WIS** | `=this.WIS` |
> **CHA** | `=this.CHA` |
> ###### Bio
>  |
> ---|---|
> **Ancestry** | `=this.Ancestry` |
> **Heritage** | `=this.Heritage` |
> **Gender** | `=this.Gender` |
> **Condition** | `=this.Condition` |
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Occupation(s)** | `=this.Occupation` |
> **Group(s)** | `=this.AssociatedGroup` |
> **Religion(s)** | `=this.AssociatedReligion` |
> **Party** | `=this.Party` |
> **Location** | `=this.Location` |

# `=this.Name`

> [!overview]- Character Summary  
Brief summary of the character’s personality, mannerisms, and overall role in the party.

> [!story]- Backstory  
Major life events, early experiences, and formative influences that define the character’s past.

> [!goals]- Aspirations  
**Short-Term Goals:** Immediate objectives or current quests.  
**Long-Term Goals:** Ideals or ambitions shaping their journey.

> [!traits]- Personality  
**Perks:** Strengths, quirks, and notable habits.  
**Flaws:** Weaknesses, vices, or challenges.

> [!culture]- Beliefs & Ideals  
Moral compass, cultural background, favored deities, or key motivations.

> [!groups]- Connections & Companions  
Family, mentors, friends, rivals, and allies both within and outside the party.

> [!Events]- Key Events  
Notable moments in their adventuring history, including session or campaign milestones.

> [!Rumors]- Reputation & Perception  
How others perceive the character — rumors, stories, or public impressions.

> [!Secrets]- Hidden Details  
Private knowledge, secrets, curses, or truths known only to the DM and player.

> [!Notes]- Notes  
General reminders, role-play hooks, or supplemental observations.
