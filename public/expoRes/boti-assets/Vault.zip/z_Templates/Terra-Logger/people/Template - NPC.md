---
BANNER: "[[NPC-Banner.jpg]]"
Name:
Pronouns:
Pronounced:
Ancestry:
Heritage:
Gender:
Age:
Sexuality:
Alignment:
Condition:
Aliases:
Occupation:
AssociatedGroup:
AssociatedReligion:
OwnedLocations:
Location:
tags:
---

> [!infobox]
> # `=this.Name` (`=this.Pronouns`)
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Bio
>  |
> ---|---|
> **Ancestry** | `=this.Ancestry` |
> **Heritage** | `=this.Heritage` |
> **Sex** | `=this.Gender` |
> **Age** | `=this.Age` |
> **Sexuality** | `=this.Sexuality` |
> **Alignment** | `=this.Alignment` |
> **Condition** | `=this.Condition` |
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Occupations** | `=this.Occupation` |
> **Groups** | `=this.AssociatedGroup` |
> **Religions** | `=this.AssociatedReligion` |
> **Owned Properties** | `=this.OwnedLocations` |
> **Current Location** | `=this.Location` |

# **`=this.Name`** <span style="font-size: medium">(`=this.occupation`)</span>
> [!overview]- Overview 
> TBD

## Aspirations
### Example


## Acquaintances
### Family:


### Friends:


### Rivals:


### Met:


## History


## DM
### Plot Hooks


### Hidden Details


### General Notes

