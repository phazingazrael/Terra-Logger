---
BANNER: "[[NPC-Banner.jpg]]"
NoteIcon: NPC
Name:
Pronouns:
Pronounced:
Ancestry:
Heritage:
Gender:
Age:
Sexuality:
Alignment:
Condition:
Aliases:
Occupation:
AssociatedGroup:
AssociatedReligion:
OwnedLocations:
Location:
tags:
---

> [!infobox]
> # `=this.Name` (`=this.Pronouns`)
> **Pronounced:** "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Bio
>  |
> ---|---|
> **Ancestry** | `=this.Ancestry` |
> **Heritage** | `=this.Heritage` |
> **Gender** | `=this.Gender` |
> **Age** | `=this.Age` |
> **Sexuality** | `=this.Sexuality` |
> **Alignment** | `=this.Alignment` |
> **Condition** | `=this.Condition` |
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Occupation(s)** | `=this.Occupation` |
> **Group(s)** | `=this.AssociatedGroup` |
> **Religion(s)** | `=this.AssociatedReligion` |
> **Owned Location(s)** | `=this.OwnedLocations` |
> **Current Location** | `=this.Location` |

# `=this.Name`

> [!overview]- Overview  
A concise description of the NPC — personality, demeanor, and public reputation.

> [!story]- Background  
Origin, upbringing, key events, and how they became who they are.

> [!goals]- Aspirations & Motivations  
Goals, desires, fears, and conflicts that drive the NPC’s actions.

> [!groups]- Relationships & Acquaintances  
Family, friends, allies, rivals, and other important social connections.

> [!Rumors]- Public Perception  
What people say about this NPC — rumors, gossip, or misinformation.

> [!Secrets]- Hidden Details  
GM-only notes: private motives, secrets, true loyalties, or concealed history.

> [!Notes]- Notes  
General notes, plot hooks, reminders, or follow-up references.
