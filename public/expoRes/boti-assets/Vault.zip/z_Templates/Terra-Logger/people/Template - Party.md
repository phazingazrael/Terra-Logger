---
BANNER: "[[Party-Banner.jpg|200]]"
Name: Party
Aliases:
Type:
Pronounced:
Status:
Theme:
Players: []
NPCAllies: []
Cohorts: []
AverageLevel:
LevelRange:
Leader: ""
Base: ""
CurrentLocation: ""
Vehicles: []
Holdings: []
Funds: ""
Resources: []
Goals: []
ActiveQuests: []
SideQuests: []
ServiceRequests: []
SessionCount:
LastSession:
tags:
---

> [!infobox]
> # `=this.file.name`
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Type** | `=this.Type` |
> **Average Level** | `=this.AverageLevel` |
> **Level Range** | `=this.LevelRange` |
> **Base** | `=this.Base` |
> **Current Location** | `=this.CurrentLocation` |
> **Funds** | `=this.Funds` |
> **Status** | `=this.Status` |
> **Last Session** | `=this.LastSession` |

# `=this.file.name`

> [!overview]- Overview  
High-level summary of the party’s identity, vibe, and current focus.

> [!party]- Roster  
> ```base
> filters:
>   and:
>     - file.inFolder("World/00. Parties/1. Characters")
>     - and:
>         - Party == this.file.name
> views:
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
>       - Class
>       - Subclass
>       - Level
> ```

> [!friend]- Allies & Contacts  
Patrons, friendly factions, mentors, and useful acquaintances.

> [!foe]- Rivals & Enemies  
Hostile factions, nemeses, bounty hunters, or competing adventuring groups.

> [!quests]- Active Quests  
> ```base
> filters:
>   and:
>     - file.inFolder("World/00. Parties/3. Quests")
>     - and:
>         - Party == this.Name
> views:
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!sidequests]- Side Quests  
> ```base
> filters:
>   and:
>     - file.inFolder("World/00. Parties/3. Quests")
>     - and:
>         - Party == this.Name
>         - Type == 'Side Quest'
> views:
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!sessionlogs]- Session Logs  
> ```base
> filters:
>   and:
>     - file.inFolder("World/00. Parties/2. Session Log")
>     - and:
>         - Party == this.Name
> views:
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!servicerequests]+ Service Requests
> ```base
> filters:
>   and:
>     - file.inFolder("World/00. Parties/4. Service Request")
>     - and:
>         - Party == this.Name
> views:
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!holdings]- Holdings  
Keeps, shops, ships, or other assets under party control.

> [!Vehicles]- Vehicles & Mounts  
Transport details, capacities, upkeep, travel speeds.

> [!Resources]- Resources & Inventory  
Special items, consumables, favors, or currencies worth tracking as a group.

> [!groups]- Factions & Reputation  
Standing with guilds, nations, religious orders; notoriety/renown notes.

> [!map]- Travel & Route  
Planned routes, waypoints, and travel conditions.

> [!Events]- Recent Events  
Major developments affecting the party since the last few sessions.

> [!Notes]- Notes  
Scratchpad for reminders, prep, and links.
