---
BANNER: "[[Deity-Banner.jpg|250]]"
NoteIcon: Deity
Name:
Type: Deity
Category: ""
Pantheon: ""
Alignment: ""
Domains: []
Symbols: []
Titles: []
HomePlane: ""
Worshippers: []
Clergy: ""
HolyDays: []
AssociatedGroups: []
tags: []
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Pantheon** | `=this.Pantheon` |
> **Alignment** | `=this.Alignment` |
> **Domains** | `=join(this.Domains, ", ")` |
> **Symbols** | `=join(this.Symbols, ", ")` |
> **Titles** | `=join(this.Titles, ", ")` |
> **Home Plane** | `=this.HomePlane` |
> **Worshippers** | `=join(this.Worshippers, ", ")` |
> **Clergy** | `=this.Clergy` |
> **Holy Days** | `=join(this.HolyDays, ", ")` |
> **Associated Groups** | `=join(this.AssociatedGroups, ", ")` |

# `=this.Name`

> [!overview]- Summary  
One-paragraph synopsis of the deity’s role and influence.

> [!History]- Origin & Myth  
Creation story, ascension, or divine lineage.

> [!culture]- Worship & Practices  
Rituals, prayers, festivals, offerings, and common taboos.

> [!Religion]- Doctrine & Beliefs  
Core tenets, commandments, and philosophies.

> [!government]- Clergy & Organization  
Priesthood structure, hierarchy, holy orders.

> [!groups]- Cults & Factions  
Major temples, sects, or schisms.

> [!places]- Sacred Sites  
Shrines, temples, holy cities, or realms of power.

> [!Artifacts]- Holy Relics  
Divine weapons, relics, scriptures, or artifacts tied to the deity.

> [!Magic]- Divine Influence  
Miracles, blessings, curses, or domains of power.

> [!Rumors]- Myths & Legends  
Tales, prophecies, or apocryphal stories.

> [!Secrets]- Hidden Truths  
GM-only revelations, forbidden doctrines, or contradictions.

> [!Notes]- Notes  
Scratchpad for reminders, links, or expansions.
