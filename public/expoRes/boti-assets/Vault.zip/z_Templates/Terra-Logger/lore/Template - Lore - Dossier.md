---
BANNER: "[[Lore-Banner.jpg]]"
NoteIcon: Lore
Name:
Type: Dossier
Subject: ""
CompiledBy: ""
Date: ""
Classification: ""
tags: []
---

> [!infobox]
> # `=this.Name`
> ###### Dossier
>  |
> ---|---|
> **Subject** | `=this.Subject` |
> **Compiled By** | `=this.CompiledBy` |
> **Date** | `=this.Date` |
> **Classification** | `=this.Classification` |

# `=this.Name`

> [!overview]- Executive Summary  
Brief of who/what this dossier covers.

> [!History]- Background  
Known history and past activities.

> [!groups]- Affiliations & Contacts  
Allies, factions, or linked individuals.

> [!Events]- Recent Activity  
Notable incidents, operations, or sightings.

> [!Resources]- Assets & Capabilities  
Skills, equipment, wealth, or resources.

> [!Secrets]- Classified Notes  
Redacted/hidden intel (GM use only).

> [!Notes]- Notes  
Cross-links, further investigations, or reminders.
