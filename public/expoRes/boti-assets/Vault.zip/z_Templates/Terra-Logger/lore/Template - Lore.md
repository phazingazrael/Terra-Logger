---
BANNER: "[[Lore-Banner.jpg]]"
NoteIcon: Lore
Type: Lore
Category: ""
Era: ""
Location: ""
Source: ""
Reliability: ""
Related: []
tags:
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Type** | `=this.Type` |
> **Category** | `=this.Category` |
> **Era** | `=this.Era` |
> **Location** | `=this.Location` |
> **Source** | `=this.Source` |
> **Reliability** | `=this.Reliability` |

# `=this.Name`

> [!overview]- Summary  
One-paragraph synopsis of the lore and why it matters.

> [!lore]- Full Text  
Primary rendition of the tale/doctrine/record.

> [!History]- Context & Provenance  
Origins, authorship/oral tradition, transmission, known edits or redactions.

> [!story]- Variants & Interpretations  
Regional versions, scholarly takes, conflicting accounts.

> [!Rumors]- Rumors & Disputed Claims  
Unverified addenda, conspiracy readings, contested passages.

> [!Secrets]- Hidden Meanings (GM)  
Esoteric readings, ciphered messages, true identities.

> [!Artifacts]- Artifacts & Items Mentioned  
List and briefly describe any items the lore references.

> [!places]- Places & Landmarks Mentioned  
Key sites tied to the lore (shrines, ruins, capitals).

> [!groups]- Factions & Figures Mentioned  
Orders, churches, rulers, heroes, villains related to the text.

> [!Bestiary]- Creatures & Entities  
Gods, monsters, spirits, or extraplanar beings in the narrative.

> [!Events]- Timeline  
Bullet a chronological sequence if relevant; cross-link events.

> [!Calendar]- Dates & Observances  
Holy days, anniversaries, recurring festivals stemming from this lore.

> [!rolltable]- Adventure Hooks
> - d6 hook prompts tying this lore into play.

> [!Notes]- Notes  
Scratchpad for citations, to-dos, or prep.
