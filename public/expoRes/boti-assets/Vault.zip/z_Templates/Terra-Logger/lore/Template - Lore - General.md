---
BANNER: "[[Lore-Banner.jpg]]"
NoteIcon: Lore
Name:
Type: General
Category: ""
Era: ""
Region: ""
AssociatedGroups: []
tags: []
---

> [!infobox]
> # `=this.file.name`
> ###### Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Era** | `=this.Era` |
> **Region** | `=this.Region` |
> **Associated Groups** | `=join(this.AssociatedGroups, ", ")` |

# `=this.file.name`

> [!overview]- Summary  
One-paragraph overview of the lore topic.

> [!History]- Origins & Timeline  
Key events, myths, or background that shaped this topic.

> [!culture]- Traditions & Practices  
Festivals, daily life, rituals, taboos, or artistic influences.

> [!government]- Governance & Politics  
Leaders, ruling bodies, laws, or conflicts.

> [!Resources]- Economy & Trade  
Materials, goods, industries, or technologies tied to this lore.

> [!groups]- Involved Factions  
Organizations, societies, or NPCs connected to the lore.

> [!places]- Significant Locations  
Important sites, landmarks, or settlements linked to the topic.

> [!Artifacts]- Relics & Items  
Unique objects, magical artifacts, or technological inventions.

> [!Magic]- Arcane Connections  
Spells, curses, or supernatural elements tied to this lore.

> [!Secrets]- Hidden Knowledge  
Unrevealed truths, mysteries, or GM-only details.

> [!Notes]- Notes  
Scratchpad for reminders, expansions, or related links.
