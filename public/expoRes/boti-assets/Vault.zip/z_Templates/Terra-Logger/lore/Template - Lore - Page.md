---
BANNER: "[[Lore-Banner.jpg]]"
NoteIcon: Lore
Name:
Type: Page
Category: ""
Era: ""
Region: ""
AssociatedGroups: []
tags: []
---


> [!lorebox] # `=this.name`
>
>> [!lore-first]
>>
>>> [!lore-desc]
>>> 
>>
>>> [!lore-aside]
>>> 
>
>> [!lore-second]
>>
>>> [!lore-desc] 
>>> 
>>> 