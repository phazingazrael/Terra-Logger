---
BANNER: "[[Lore-Banner.jpg]]"
NoteIcon: Lore
Name:
Type: Rumor
Category: ""
Source: ""
Credibility: ""
tags: []
---

> [!infobox]
> # `=this.file.name`
> ###### Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Source** | `=this.Source` |
> **Credibility** | `=this.Credibility` |

# `=this.file.name`

> [!overview]- Rumor Summary  
The circulating story, gossip, or half-truth.

> [!Rumors]- Details  
Fragments, who’s spreading it, and why it matters.

> [!Secrets]- Truth Behind It  
What’s really going on (GM notes).

> [!Notes]- Notes  
Connections, follow-up, or session use.
