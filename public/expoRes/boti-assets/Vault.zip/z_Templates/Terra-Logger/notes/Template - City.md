---
BANNER: "[[City-Banner.jpg|150]]"
NoteIcon: Note
Type: City
Name:
tags:
Content:
---
 
# `=this.Name` Description

`=this.Content`
