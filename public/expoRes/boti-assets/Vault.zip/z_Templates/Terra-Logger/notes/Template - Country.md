---
BANNER: "[[Country-Banner.png|-100]]"
NoteIcon: Note
Type: Country
Name:
tags:
Content:
---
# `=this.Name` Details

`=this.Content`
