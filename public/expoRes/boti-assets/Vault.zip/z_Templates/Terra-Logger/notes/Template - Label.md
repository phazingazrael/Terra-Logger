---
BANNER: "[[Lore-Banner.jpg]]"
NoteIcon: Note
Type: Label
Name:
tags:
Content:
---
# `=this.Name` Details
`=this.Content`
