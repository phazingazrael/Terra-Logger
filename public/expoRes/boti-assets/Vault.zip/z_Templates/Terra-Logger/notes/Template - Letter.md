---
BANNER: "[[Letter-Banner.jpg|200]]"
NoteIcon: Note
Type: Letter
Name:
tags:
Status:
Recipient:
Sender:
---

# `=this.Name`

> [!info]- Status
> **Status:** `=this.Status` 

> [!letters] Letter 
>> [!column|3 no-title]
>> To: `=this.Recipient`
>
>> [!notes|no-title]+ Contents
>> Letter contents that has been sent to the Character.
>
>> [!notes] Notes
>> Notes for anything to do with the letter being sent to the sender.

> [!response] 
>> [!column|3 no-title]
>> From: `=this.Recipient`
>
>> [!notes|no-title]+ Contents
>> Letter contents that has been received.
>
>> [!notes] Notes
>> Notes for anything to do with the letter being received.