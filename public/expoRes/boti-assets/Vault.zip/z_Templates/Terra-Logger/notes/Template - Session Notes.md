---
NoteIcon: Note
Type: Session Note
Name:
Aliases:
Party:
tags:
BANNER: "[[SesionLogs-Banner.jpg|150]]"
---

#  **`=this.Name` "`=this.Aliases`" (`=this.WhichParty`)**
## Prep
> [!column|2 no-title]
>> [!sessionlogs] To Do
>>
>
>> [!story] Plan
>>


### Quick References
> [!column|3 no-title]
>> [!characters]+ People
>> TBD
>
>> [!places]+ Places
>> TBD
>
>> [!misc]+ Misc
>> TBD

## During
> [!column|3 no-title]
>> [!events]+ Events
>> TBD
>
>> [!travel]+ Travel & Rest
>> TBD
>
>> [!treasure]+ Loot, Rewards & Purchases
>> TBD


## Post
> [!column|3 no-title]
>> [!technology]+ New Creations
>> TBD
>
>> [!calendar]+ Date & Time
>> TBD
>
>> [!notes]+ End of Session Notes
>> TBD
