---
BANNER: "[[Military-Banner.jpg]]"
NoteIcon: Note
Type: Military
Name:
tags:
Content:
Allegiance:
Commander:
Status:
LastSeen:
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Type** | `=this.Type` |
> **Allegiance** | `=this.Allegiance` |
> **Commander** | `=this.Commander` |
> **Status** | `=this.Status` |
> **Last Seen** | `=this.LastSeen` |

# **`=this.Name`**

> [!military]- `=this.Name` Details
> `=this.Content`