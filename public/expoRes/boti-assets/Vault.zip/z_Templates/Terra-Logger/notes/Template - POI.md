---
BANNER: "[[POI-Banner.jpg]]"
NoteIcon: Note
Type: Point of Interest
Name:
tags:
Content:
Category:
Significance:
Hazard:
Access:
Owner:
Condition:
LastSeen:
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Type** | `=this.Type` |
> **Category** | `=this.Category` |
> **Significance** | `=this.Significance` |
> **Hazard** | `=this.Hazard` |
> **Access** | `=this.Access` |
> **Owner** | `=this.Owner` |
> **Condition** | `=this.Condition` |
> **Last Seen** | `=this.LastSeen` |
 
# `=this.Name`

> [!pois]- `=this.Name` Details
`=this.Content`
