---
BANNER: "[[ShopsServices-Banner.jpg|100]]"
Name:
Pronounced:
Aliases:
Type:
Owners:
Staff:
Location:
AffiliatedGroup:
tags:
---

> [!infobox]
> # `=this.Name`
> **Pronounced:** "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Type** | `=this.Type` |
> **Owner(s)** | `=this.Owners` |
> **Staff** | `=this.Staff` |
> **Location** | `=this.Location` |
> **Group(s)** | `=this.AffiliatedGroup` |

# `=this.Name`

> [!overview]- Summary  
Brief introduction to the shop or service — what it sells, who frequents it, and its general atmosphere.

> [!story]- History  
When and how the shop was founded, important changes in ownership, or notable historical events tied to it.

> [!shops]- Services & Offerings  
List or describe goods, services, or specialties provided here.

> [!groups]- Staff & Affiliations  
Key employees, their responsibilities, and relationships with any guilds, patrons, or factions.

> [!Rumors]- Local Reputation  
What people say about the shop — rumors, praise, or scandal.

> [!Secrets]- Hidden Details  
GM-only notes such as secret dealings, hidden rooms, or magical enchantments.

> [!Notes]- Notes  
General scratchpad for ideas, reminders, or campaign references.
