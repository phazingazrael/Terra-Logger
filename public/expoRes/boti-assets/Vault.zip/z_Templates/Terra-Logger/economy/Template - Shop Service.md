---
BANNER: "[[ShopsServices-Banner.jpg|100]]"
Name:
Pronounced:
Aliases:
Type:
Owners:
Staff:
Location:
AffiliatedGroup:
tags:
---

> [!infobox]
> # `=this.Name`
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.aliases` |
> **Type** | `=this.type` |
> **Owner(s)** | `=this.owners` |
> **Staff** | `=this.staff` |
> **Location** | `=this.location` |
> **Group(s)** | `=this.AffiliatedGroup` |

# **`=this.Name`**
> [!recite]- Introduction
TBD

## History


## DM Notes
### Hidden Details


### Notes

