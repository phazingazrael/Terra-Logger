---
BANNER: "[[ServiceRequest-Banner.jpg|300]]"
NoteIcon: Service Request
Type: Service Request
Name:
Category: ""
Status: ""
RequestedBy: ""
Beneficiary: ""
Location: ""
Deadline: ""
Requested: ""
Started: ""
Completed: ""
Difficulty: ""
Urgency: ""
Repeatable: ""
RecommendedLevel: ""
RecommendedParty: ""
Rewards: []
Reputation: ""
PaymentTerms: ""
tags: []
Party:
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Status** | `=this.Status` |
> **Requested By** | `=this.RequestedBy` |
> **Beneficiary** | `=this.Beneficiary` |
> **Location** | `=this.Location` |
> **Difficulty** | `=this.Difficulty` |
> **Urgency** | `=this.Urgency` |
> **Repeatable** | `=this.Repeatable` |
> **Recommended Level** | `=this.RecommendedLevel` |
> **Recommended Party** | `=this.RecommendedParty` |
> **Deadline** | `=this.Deadline` |
> **Requested** | `=this.Requested` |
> **Started** | `=this.Started` |
> **Completed** | `=this.Completed` |
> **Rewards** | `=join(this.Rewards, ", ")` |
> **Reputation** | `=this.Reputation` |
> **Payment Terms** | `=this.PaymentTerms` |

# `=this.Name`

> [!overview]- Summary  
One-paragraph synopsis of the request, scope, and desired outcome.

> [!servicerequests]- Scope & Terms  
Work description, acceptance criteria, service level expectations, handoff/verification steps.

> [!quests]- Objectives  
> - [ ] Primary goal  
> - [ ] Secondary task(s)  
> - [ ] Optional bonus

> [!groups]- Parties & Stakeholders  
Requestor, beneficiary, intermediaries, and any overseeing factions.

> [!places]- Work Sites  
Key locations, access notes, and travel considerations.

> [!Items]- Deliverables & Compensation  
Breakdown of deliverables, milestones, and reward structure.

> [!Traps]- Constraints & Risks  
Legal constraints, hazards, fail conditions, escalation paths.

> [!Events]- Activity Log  
Dated/session-stamped updates, decisions, outcomes.

> [!Rumors]- Intel & Leads  
Unverified info, tips, competing bids.

> [!Secrets]- GM Notes  
Hidden terms, true motives, consequences of refusal.

> [!Notes]- Notes  
Scratchpad for reminders and links.
