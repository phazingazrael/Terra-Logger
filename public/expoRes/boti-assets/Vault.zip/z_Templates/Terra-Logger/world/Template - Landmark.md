---
BANNER: "[[Landmark-Banner.jpg|150]]"
Name:
NoteIcon:
Pronounced:
Type:
Owners:
Staff:
Country:
tags:
---

> [!infobox]
> # `=this.Name`
> **Pronounced:** "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Type** | `=this.Type` |
> **Owners** | `=this.Owners` |
> **Staff** | `=this.Staff` |
> **Country** | `=this.Country` |

# `=this.Name`

> [!overview]- Overview  
Brief description of the landmark — appearance, significance, and what it’s known for.

> [!story]- History  
Origins, construction, founders, or key historical events tied to the site.

> [!districts]- Keyed Locations  
> Sub-areas, notable rooms, or points within this landmark.  
> ```base
> filters:
>   and:
>     - file.inFolder("World/11. Keyed Locations")
>     - and:
>         - file.hasProperty("Location")
>         - Location == this.Name
> views:
>   - type: table
>     name: Table
>     order:
>       - file.name
>       - Name
>       - Type
>       - Category
>       - Connections
>       - Environment
>       - Features
>       - Hazards
>       - Inhabitants
>       - Key
>       - ParentMap
>       - Secrets
>       - Treasures
>       - tags
>     limit: 50
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!groups]- Associated Groups  
> Factions, organizations, or entities connected to this location.
> ```base
> filters:
>   and:
>     - file.inFolder("World/12. Groups")
>     - and:
>         - file.hasProperty("Location")
>         - Location == this.Name
> views:
>   - type: table
>     name: Table
>     limit: 50
>     order:
>       - file.name
>       - Pronounced
>       - Name
>       - Type
>       - Location
>       - HQ
>       - AssociatedReligion
>       - Alignment
>       - tags
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!characters]- NPCs
> NPCs or historical figures linked to the landmark’s story.
> ```base
> filters:
>   and:
>     - file.inFolder("World/13. NPCs")
>     - and:
>         - file.hasProperty("Location")
>         - Location == this.Name
> views:
>   - type: table
>     name: Table
>     limit: 50
>     order:
>       - file.name
>       - Name
>       - Pronounced
>       - Pronouns
>       - Occupation
>       - Location
>       - Gender
>       - Condition
>       - Alignment
>       - Ancestry
>       - OwnedLocations
>       - AssociatedGroup
>       - AssociatedReligion
>       - Heritage
>       - Sexuality
>       - tags
>   - type: cards
>     name: Cards
>     order:
>       - file.name
>       - Name
> ```

> [!Rumors]- Local Lore  
Tales, myths, or superstitions surrounding this place.

> [!Secrets]- Hidden Details  
GM-only notes — traps, secret chambers, curses, or mysteries.

> [!Notes]- Notes  
General notes, future hooks, or references to related places.
