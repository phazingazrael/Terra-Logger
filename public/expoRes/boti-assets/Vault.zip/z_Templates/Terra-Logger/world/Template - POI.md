---
BANNER: "[[POI-Banner.jpg]]"
NoteIcon: POI
Name:
Type: POI
Category: ""
ParentArea: ""
Established: ""
Owner: ""
Groups: []
Services: []
Features: []
Secrets: []
tags: []
---

> [!infobox]
> # `=this.Name`
> ###### POI Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Parent Area** | `=this.ParentArea` |
> **Established** | `=this.Established` |
> **Owner** | `=this.Owner` |
> **Groups** | `=join(this.Groups, ", ")` |
> **Services** | `=join(this.Services, ", ")` |
> **Features** | `=join(this.Features, ", ")` |
> **Secrets** | `=join(this.Secrets, ", ")` |

# `=this.Name`

> [!overview]- Description  
Flavor text and overview of the POI.

> [!story]- History  
Founding, events, or background stories.

> [!groups]- Ties & Factions  
Connections to guilds, cults, noble houses, or NPCs.

> [!shops]- Services & Offerings  
Goods, services, or activities available here.

> [!landmarks]- Features & Architecture  
Unique design, curiosities, magical details, or décor.

> [!Rumors]- Local Rumors & Hooks  
Street gossip, adventure leads, or NPC chatter.

> [!Secrets]- Hidden Truths  
GM-only lore, hooks, or concealed purposes.

> [!Notes]- Notes  
Session-use notes, scratchpad, or links.
