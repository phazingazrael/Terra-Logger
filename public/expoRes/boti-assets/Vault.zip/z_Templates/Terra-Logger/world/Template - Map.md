---
BANNER:
NoteIcon: Map
Width:
Height:
Name:
Seed:
Ver:
Era:
EraShort:
TemperatureEquator:
TemperatureNorthPole:
TemperatureSouthPole:
Year:
tags:
Winds:
  - "90° North:"
  - "60° North:"
  - "30° North:"
  - "30° South:"
  - "60° South:"
  - "90° South:"
---

> [!infobox]
> # `=this.Name`
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Type** | `=this.NoteIcon` |
> **Width × Height** | `=this.Width` × `=this.Height` |
> **Era (Year)** | `=this.Era` (`=this.Year`) |
> **Version** | `=this.Ver` |
> **Seed** | `=this.Seed` |
> **Planet/Plane** | `=this.PlanetPlane` |


# **`=this.Name`**

> [!overview]- Overview  
> Purpose of this map (world, continent, region), what it depicts, and how to read it.

> [!Regions]- Regions & Zones  
> Named regions, political divisions, or biome zones referenced on the map.

> [!landmarks]- Landmarks  
> Mountains, canyons, great forests, monuments, megastructures, etc.

> [!Travel]- Routes & Navigation  
> Roads, sea lanes, air corridors, portals; hazards or checkpoints.

> [!Weather]- Climate & Biomes  
> Prevailing winds and temperature notes (use if relevant)
> - **Winds:** 
>   - `=this.Winds[0]`
>   - `=this.Winds[1]`
>   - `=this.Winds[2]`
>   - `=this.Winds[3]`
>   - `=this.Winds[4]`
>   - `=this.Winds[5]`
> - **Equator Temp:** `=this.TemperatureEquator`  
> - **North Pole:** `=this.TemperatureNorthPole`  
> - **South Pole:** `=this.TemperatureSouthPole`

> [!History]- Historical Changes  
> Borders, coastlines, or settlements that have shifted over time.

> [!Events]- Recent Events  
> Quakes, eruptions, invasions, discoveries—anything that changes the map.

> [!Notes]- Notes  
> Scratchpad for reminders, to-dos, and references.

---

> [!Rumors]- Rumors  
> Unverified places, hidden routes, or alleged lost cities.

> [!Secrets]- Secrets  
> GM-only locations, concealed passages, or false labels.

> [!lore]- Lore  
> Origin myths, ancient cartographers, or legendary maps tied to this world.