---
BANNER: "[[District-Banner.jpg|-150]]"
NoteIcon: District
Name:
Type: District
City: ""
Category: ""
Population: ""
Demographics: ""
Culture: ""
Economy: ""
Government: ""
Groups: []
Landmarks: []
Shops: []
POIs: []
Safety: ""
tags: []
---

> [!infobox]
> # `=this.Name`
> ###### District Info
>  |
> ---|---|
> **City** | `=this.City` |
> **Category** | `=this.Category` |
> **Population** | `=this.Population` |
> **Demographics** | `=this.Demographics` |
> **Culture** | `=this.Culture` |
> **Economy** | `=this.Economy` |
> **Government** | `=this.Government` |
> **Groups** | `=join(this.Groups, ", ")` |
> **Landmarks** | `=join(this.Landmarks, ", ")` |
> **Shops** | `=join(this.Shops, ", ")` |
> **Points of Interest** | `=join(this.POIs, ", ")` |
> **Safety** | `=this.Safety` |

# `=this.Name`

> [!overview]- Summary  
Overview of the district’s role and identity within the city.

> [!demographics]- Demographics & Culture  
Breakdown of population makeup, traditions, and unique traits.

> [!economy]- Economy & Trade  
Markets, industries, and guild activity.

> [!government]- Governance & Law  
Local authorities, guild masters, noble houses, and justice.

> [!groups]- Factions & Organizations  
Active powers, criminal groups, temples, or guilds.

> [!landmarks]- Landmarks & Architecture  
Notable sites, monuments, taverns, temples, or special buildings.

> [!shops]- Shops & Vendors  
List of key shops, inns, taverns, and businesses.

> [!pois]- Points of Interest  
Hidden alleys, curiosities, or minor notable sites.

> [!Rumors]- Rumors & Hooks  
Street gossip, adventure seeds, and political intrigue.

> [!Secrets]- Hidden Truths  
Underground networks, conspiracies, or forbidden lore.

> [!Notes]- Notes  
Additional details, scratchpad, or links.
