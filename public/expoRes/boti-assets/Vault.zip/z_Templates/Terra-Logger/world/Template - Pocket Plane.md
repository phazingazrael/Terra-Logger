---
BANNER: "[[Plane-Banner.jpg]]"
NoteIcon: Plane
Name:
Type: Plane - Pocket
Category: ""
Creator: ""
Purpose: ""
AccessMethods: []
Stability: ""
Duration: ""
ConnectedPlanes: []
Traits: []
Inhabitants: []
RulingEntities: []
Hazards: []
Secrecy: ""
tags: []
---

> [!infobox]
> # `=this.Name`
> ###### Pocket Plane
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Creator** | `=this.Creator` |
> **Purpose** | `=this.Purpose` |
> **Access Methods** | `=join(this.AccessMethods, ", ")` |
> **Stability** | `=this.Stability` |
> **Duration** | `=this.Duration` |
> **Connected Planes** | `=join(this.ConnectedPlanes, ", ")` |
> **Traits** | `=join(this.Traits, ", ")` |
> **Inhabitants** | `=join(this.Inhabitants, ", ")` |
> **Ruling Entities** | `=join(this.RulingEntities, ", ")` |
> **Hazards** | `=join(this.Hazards, ", ")` |
> **Secrecy** | `=this.Secrecy` |

# `=this.Name`

> [!overview]- Summary  
One-paragraph overview of the pocket plane’s nature and purpose.

> [!story]- Origin & Creation  
Who made it, when, and why.

> [!map]- Layout & Boundaries  
How the space is structured (single chamber, infinite hall, labyrinth, shard-world, etc.).

> [!Resources]- Traits & Properties  
Gravity, magic rules, time flow, and special features.

> [!places]- Important Features  
Vaults, sanctums, gardens, prisons, or unique landmarks.

> [!Bestiary]- Inhabitants  
Native or trapped creatures, guardians, echoes, or constructs.

> [!groups]- Controllers & Intruders  
The ruling entity, challengers, cults, or outsiders.

> [!Traps]- Hazards & Challenges  
Magical traps, entropy, unstable magic, psychic bleed, or collapsing space.

> [!Secrets]- Hidden Truths  
What lies beneath the surface, forgotten purposes, or GM-only notes.

> [!Notes]- Notes  
Hooks for sessions, links, or further elaboration.
