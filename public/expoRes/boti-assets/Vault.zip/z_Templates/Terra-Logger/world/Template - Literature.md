---
BANNER: "[[Literature-Banner.jpg|-150]]"
NoteIcon: Literature
Name:
Type: Literature
Category: ""
Author: ""
Scribe: ""
DateWritten: ""
Origin: ""
Language: ""
Genre: ""
Condition: ""
Copies: ""
KnownHolders: []
AssociatedGroups: []
Tags: []
---

> [!infobox]
> # `=this.Name`
> ###### Literature Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Author** | `=this.Author` |
> **Scribe** | `=this.Scribe` |
> **Date Written** | `=this.DateWritten` |
> **Origin** | `=this.Origin` |
> **Language** | `=this.Language` |
> **Genre** | `=this.Genre` |
> **Condition** | `=this.Condition` |
> **Copies** | `=this.Copies` |
> **Known Holders** | `=join(this.KnownHolders, ", ")` |
> **Associated Groups** | `=join(this.AssociatedGroups, ", ")` |

# `=this.Name`

> [!overview]- Summary  
Brief description of the work’s contents and significance.

> [!History]- Origins & Authorship  
When, where, and why it was written. Notes on the author or scribe.

> [!story]- Content & Themes  
Plot, doctrine, knowledge, or artistic themes explored.

> [!culture]- Influence & Reception  
How different groups view the work — revered, banned, obscure, or misunderstood.

> [!groups]- Associated Groups  
Factions, cults, libraries, or schools tied to the text.

> [!Artifacts]- Physical Form  
Special bindings, magical qualities, illustrations, or materials.

> [!Rumors]- Myths & Reputation  
Whispers, legends, or contested truths about the work.

> [!Secrets]- Hidden Knowledge  
GM-only content: encoded passages, dangerous spells, forbidden doctrines.

> [!Notes]- Notes  
Additional references, links, or campaign usage.
