---
BANNER: "[[Plane-Banner.jpg]]"
NoteIcon: Plane
Name:
Type: Plane
Category: ""
Alignment: ""
Nature: ""
ParentPlane: ""
Subplanes: []
ConnectedPlanes: []
AccessMethods: []
Traits: []
Inhabitants: []
RulingEntities: []
TimeFlow: ""
Hazards: []
tags: []
---

> [!infobox]
> # `=this.Name`
> ###### Cosmology
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Alignment** | `=this.Alignment` |
> **Nature** | `=this.Nature` |
> **Parent Plane** | `=this.ParentPlane` |
> **Subplanes** | `=join(this.Subplanes, ", ")` |
> **Connected Planes** | `=join(this.ConnectedPlanes, ", ")` |
> **Access Methods** | `=join(this.AccessMethods, ", ")` |
> **Traits** | `=join(this.Traits, ", ")` |
> **Inhabitants** | `=join(this.Inhabitants, ", ")` |
> **Ruling Entities** | `=join(this.RulingEntities, ", ")` |
> **Time Flow** | `=this.TimeFlow` |
> **Hazards** | `=join(this.Hazards, ", ")` |

# `=this.Name`

> [!overview]- Summary  
High-level description of the plane and its role in the cosmos.

> [!story]- Myth & Origin  
Creation myths, first explorers, or divine purpose.

> [!map]- Geography & Structure  
How the plane is shaped: infinite expanse, layered, bounded, or fragmented.

> [!Resources]- Traits & Properties  
Gravity, magic, time flow, perception, and unique physical laws.

> [!places]- Key Locations  
Famous regions, realms, or landmarks within the plane.

> [!Bestiary]- Inhabitants  
Common denizens, planar creatures, or unique species.

> [!groups]- Ruling Powers & Factions  
Gods, overlords, councils, or cosmic hierarchies.

> [!Traps]- Hazards & Challenges  
Planar storms, corruption, madness, entropy, or traps.

> [!Magic]- Arcane Influence  
Planar-specific spells, boons, curses, or magical phenomena.

> [!Rumors]- Myths & Legends  
Stories, prophecies, or forbidden knowledge tied to the plane.

> [!Secrets]- Hidden Truths  
GM-only mysteries, connections, or revelations.

> [!Notes]- Notes  
Scratchpad for campaign use, cross-references, or ideas.
