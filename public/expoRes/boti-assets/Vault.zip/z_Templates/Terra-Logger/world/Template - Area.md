---
BANNER: "[[Area-Banner.jpg|200]]"
NoteIcon: Area
Name:
Type: Area
Category: ""
ParentRegion: ""
Climate: ""
Terrain: ""
Control: ""
Resources: []
Landmarks: []
Settlements: []
Encounters: []
Hazards: []
ConnectedAreas: []
tags: []
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Parent Region** | `=this.ParentRegion` |
> **Climate** | `=this.Climate` |
> **Terrain** | `=this.Terrain` |
> **Control** | `=this.Control` |
> **Resources** | `=join(this.Resources, ", ")` |
> **Landmarks** | `=join(this.Landmarks, ", ")` |
> **Settlements** | `=join(this.Settlements, ", ")` |
> **Encounters** | `=join(this.Encounters, ", ")` |
> **Hazards** | `=join(this.Hazards, ", ")` |
> **Connected Areas** | `=join(this.ConnectedAreas, ", ")` |

# `=this.Name`

> [!overview]- Summary  
High-level description of the area’s purpose, character, and notable features.

> [!map]- Geography & Layout  
Physical description, borders, pathways, and subzones.

> [!landmarks]- Landmarks  
Detailed notes on major features, ruins, shrines, or natural wonders.

> [!settlements]- Settlements  
Towns, villages, camps, fortresses, or hidden enclaves.

> [!Bestiary]- Inhabitants & Encounters  
Creatures, NPCs, factions, or encounter tables.

> [!Traps]- Hazards & Dangers  
Environmental threats, magical anomalies, or unique terrain challenges.

> [!Resources]- Resources & Economy  
Natural, magical, or strategic assets.

> [!groups]- Controlling Powers  
Factions, rulers, or political entities influencing this area.

> [!Rumors]- Local Rumors & Hooks  
What adventurers might hear about the area.

> [!Secrets]- Hidden Knowledge  
GM-only details, twists, or secret connections.

> [!Notes]- Notes  
Additional details, scratchpad, or cross-links.
