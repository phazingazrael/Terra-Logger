---
BANNER: "[[KeyedLocation-Banner.jpg|-100]]"
NoteIcon: Location
Name:
Type: Keyed Location
Key: ""
ParentMap: ""
Category: ""
Environment: ""
Features: []
Inhabitants: []
Treasures: []
Hazards: []
Connections: []
Secrets: []
tags: []
Location:
---

> [!infobox]
> # `=this.Name`
> ###### Location Info
>  |
> ---|---|
> **Key** | `=this.Key` |
> **Parent Map** | `=this.ParentMap` |
> **Category** | `=this.Category` |
> **Environment** | `=this.Environment` |
> **Features** | `=join(this.Features, ", ")` |
> **Inhabitants** | `=join(this.Inhabitants, ", ")` |
> **Treasures** | `=join(this.Treasures, ", ")` |
> **Hazards** | `=join(this.Hazards, ", ")` |
> **Connections** | `=join(this.Connections, ", ")` |
> **Secrets** | `=join(this.Secrets, ", ")` |

# `=this.Name`

> [!overview]- Description  
Read-aloud text or GM description for the keyed location.

> [!map]- Layout & Connections  
How this location connects to others; doors, tunnels, roads, or hidden passages.

> [!landmarks]- Features  
Physical traits, architecture, furnishings, or curiosities.

> [!Bestiary]- Inhabitants  
Creatures, NPCs, or spirits encountered here.

> [!Traps]- Hazards & Dangers  
Traps, curses, magical anomalies, or natural threats.

> [!Items]- Treasures & Rewards  
Loot, valuables, magical items, or artifacts.

> [!Rumors]- Hooks & Lore  
Legends, adventurer notes, or hearsay tied to this place.

> [!Secrets]- GM Notes  
Hidden information, secret triggers, or puzzles.

> [!Notes]- Notes  
Scratchpad for session use, adjustments, or links.
