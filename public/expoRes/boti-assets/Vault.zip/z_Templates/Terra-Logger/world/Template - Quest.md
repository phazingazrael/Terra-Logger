---
BANNER: "[[Quest-Banner.jpg|-200]]"
NoteIcon: Quest
Name:
Type: Quest
Category: ""
Status: ""
GivenBy: ""
Location: ""
Deadline: ""
Started: ""
Completed: ""
Difficulty: ""
Urgency: ""
Level: ""
Rewards: []
tags: []
Party:
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Category** | `=this.Category` |
> **Status** | `=this.Status` |
> **Given By** | `=this.GivenBy` |
> **Location** | `=this.Location` |
> **Difficulty** | `=this.Difficulty` |
> **Urgency** | `=this.Urgency` |
> **Level** | `=this.Level` |
> **Deadline** | `=this.Deadline` |
> **Started** | `=this.Started` |
> **Completed** | `=this.Completed` |
> **Rewards** | `=join(this.Rewards, ", ")` |
> **Code** | `=this.Code` |
 
# `=this.Name`

> [!overview]- Summary  
One-paragraph synopsis of the quest and desired outcome.

> [!quests]- Objectives  
> - [ ] Primary goal  
> - [ ] Secondary task(s)  
> - [ ] Optional bonus

> [!story]- Background  
History, motivation, why this matters.

> [!groups]- Quest Giver & Factions  
Allies, patrons, involved organizations; stakes and politics.

> [!places]- Key Locations  
Sites to visit, dungeons, travel notes.

> [!Bestiary]- Adversaries  
Creatures, rival parties, notable NPC opposition.

> [!Traps]- Hazards  
Environmental dangers, curses, traps, complications.

> [!Items]- Rewards (Detailed)  
Elaborate on the items/boons listed in frontmatter `Rewards`.

> [!Events]- Progress Log  
Dated/session-stamped updates, decisions, outcomes.

> [!Rumors]- Leads & Clues  
Unverified info, tips, red herrings.

> [!Secrets]- GM Notes  
Hidden twists, fail conditions, clock/timer notes.

> [!Notes]- Notes  
Scratchpad for reminders and links.
