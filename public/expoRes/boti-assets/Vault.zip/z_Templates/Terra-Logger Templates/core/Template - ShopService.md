---
BANNER: "[[adrianna-kaczmarek-PMNSy4ZEkT4-unsplash.jpg|100]]"
Pronounced:
Aliases:
Type:
Owners:
Staff:
Location:
AffiliatedGroup:
---

> [!infobox]
> # `=this.Name`
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.aliases` |
> **Type** | `=this.type` |
> **Owner(s)** | `=this.owners` |
> **Staff** | `=this.staff` |
> **Location** | `=link(this.location)` |
> **Group(s)** | `=link(this.AffiliatedGroup)` |

# **`=this.Name`**
> [!recite]- Introduction
TBD

## History


## DM Notes
### Hidden Details


### Notes

