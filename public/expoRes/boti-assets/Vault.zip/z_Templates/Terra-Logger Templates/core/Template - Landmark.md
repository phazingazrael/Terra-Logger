---
BANNER: "[[ron-baron-YF86VTMn9r0-unsplash.jpg|150]]"
this.Pronounced::
type:
owners:
staff:
Country:
---

> [!infobox]
> # `=this.Name`
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Info
>  |
> ---|---|
> **Type** | `=this.type` |
> **Owners** | `=this.owners` |
> **Staff** | `=this.staff` |
> **Country** | `=link(this.Country)` |

# `=this.Name`
> [!recite]- Introduction
TBD

> [!overview]- Overview
> TBD

> [!districts]- Keyed Locations
> [[🔑 Keyed Location Database|🔑Add New Keyed Location]]
> ```dataview
table join(aliases, ", ") AS Aliases, key, join(type, ", ") AS Types
WHERE Location = this.Name AND contains(NoteIcon, "Key")
SORT file.name ASC

> [!groups]- Groups
> [[🔰 Group Database| 🔰 Add New Group]]
> ```dataview
table join(aliases, ", ") AS Aliases, join(type, ", ") AS Types
WHERE econtains(Location, this.Name) AND contains(NoteIcon, "Group")
SORT file.name ASC

> [!characters]- Characters
> [[👨‍👩‍👧‍👦 NPC Database| 📝Add New NPC]]
> ```dataview
table join(aliases, ", ") AS Aliases, join(occupation, ", ") AS "Occupations", join(link(associatedgroup), ", ") AS "Groups"
WHERE Location = this.Name AND contains(NoteIcon, "Character") AND !contains(Condition, "Dead")
SORT file.name ASC

## History


## DM Notes
### Hidden Details


### Notes