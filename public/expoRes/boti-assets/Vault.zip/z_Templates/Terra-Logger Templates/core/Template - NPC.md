---
BANNER: "[[IDCard.png|50]]"
pronouns:
Pronounced:
Ancestry:
Heritage:
Gender:
Age:
Sexuality:
Alignment:
Condition:
Aliases:
Occupation:
AssociatedGroup:
AssociatedReligion:
OwnedLocations:
Location:
---

> [!infobox]
> # `=this.Name` (`=this.Pronouns`)
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Bio
>  |
> ---|---|
> **Ancestry** | `=this.Ancestry` |
> **Heritage** | `=this.Heritage` |
> **Sex** | `=this.Gender` |
> **Age** | `=this.Age` |
> **Sexuality** | `=this.Sexuality` |
> **Alignment** | `=this.Alignment` |
> **Condition** | `=this.Condition` |
> ###### Info
>  |
> ---|---|
> **Aliases** | `=this.Aliases` |
> **Occupations** | `=this.Occupation` |
> **Groups** | `=link(this.AssociatedGroup)` |
> **Religions** | `=link(this.AssociatedReligion)` |
> **Owned Properties** | `=link(this.OwnedLocations)` |
> **Current Location** | `=link(this.Location)` |

# **`=this.Name`** <span style="font-size: medium">(`=this.occupation`)</span>
> [!overview]- Overview 
> TBD

## Aspirations
### Example


## Acquaintances
### Family:


### Friends:


### Rivals:


### Met:


## History


## DM
### Plot Hooks


### Hidden Details


### General Notes

