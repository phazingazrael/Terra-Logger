> [!infobox]
> # `=this.file.name`
> **Pronounced:**  "`=this.Pronounced`"
> ![[PlaceholderImage.png]]
> ###### Basic Information
>  |
> ---|---|
> **Aliases** | `=this.aliases` |
> **Base of Operations** | `=link(this.hq)` |
> **Associated Religion** | `=link(this.associatedreligion)` |
> **Alignment** | `=this.alignment` |
> **Type** | `=this.type` |

# LORE

## **Abomination**

  

They are called by many names: the “Undying Children”, the “Damned Urrah”, the “Vrykolakas”, the “Pale Ones” and “Luna’s Demons”. But in general they are best known simply as the “Abominations”. However, very few Fera would survive the Embrace. Some of them linger on in agony for a time before death, but most die instantly and painlessly (and many werewolves believe they are being spared of Wyrm’s curse through the blessing of Gaia).

  

A rare few, however, do not die. These Garou become a cross between werewolf and vampire — an “Abomination”. It is not known why Gaia allows this to happen, though some stories suggest those whose souls are already corrupted or who have been driven to Harano may be Embraced. Some Garou, hearing these stories, actively seek Kindred out for the Embrace, whether from fear of death or desire for power is unknown.

  

Abominations are feared by Garou and Kindred alike. They are extremely powerful and are quickly driven mad by the Embrace, becoming bestial and incapable of acting even normal human — endangering the Masquerade and the Veil. As a result, vampires and werewolves hunt and destroy Abominations as quickly as possible, and most live brief but bloody lives. But there are some cases where, with a steadfast resolution and iron moral choices, they are the most dangerous of all, for if a single Abomination learns to use their powers the right way, they could be one of the most powerful entities the earth has ever seen.

  

---

  

## Lore

  

### • Form Shift

You did not lose the ability to shape change upon your Embrace. You are no longer able to heal normally, but you can make a rouse check to heal as a Kindred would. When shapechanged, a single rouse check can be used to heal one point of **Aggravated** damage.

  

### •• Discipline Affinity

You are able to learn any Discipline from any clan, due to your Wyrm corruption. You follow the same rules that Caitiff do when learning Disciplines.

  

### ••• Gaia’s Chosen

Despite most of your kind being Wyrm-tainted, you managed to escape this fate, either by some miracle or by your immense amount of faith in your abilities. You may generate **Gnosis** as you did before death and use all of the abilities you previously had access to.

  

### •••• Ego Starved

Your downward spiral into corruption is slowed considerably. Every time you make a **remorse** roll, you may add **2** additional dice to your pool.

  

### ••• Pack Tactics

You are aware of several others like yourself and can call on them to assist you with multiple things. They see you as a sort of inspiration and look to you for guidance. You gain **six dots** to split among **Allies**, **Influence**, and **Contacts** as you see fit. The connections gained from this loresheet can be directed, but never outright controlled. You are a leader, not a tyrant.