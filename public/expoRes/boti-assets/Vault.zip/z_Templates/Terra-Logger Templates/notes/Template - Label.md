---
BANNER:
# --- Identification ---
NoteIcon: Note
Type: "Label"
Name:
# --- Content ---
Content:
---
# `=this.Name` Details
`=this.Content`
