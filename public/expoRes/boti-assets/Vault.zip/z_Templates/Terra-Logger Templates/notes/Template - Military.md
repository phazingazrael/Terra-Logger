---
BANNER:
NoteIcon: Note
Type: Military
Name:
# --- Content ---
Content:
Allegiance:
Commander:
Status:     # active, garrisoned, marching, routed
LastSeen:   # date or session number
---

> [!infobox]
> # `=this.Name`
> ###### Info
>  |
> ---|---|
> **Type** | `=this.Type` |
> **Allegiance** | `=this.Allegiance` |
> **Commander** | `=this.Commander` |
> **Status** | `=this.Status` |
> **Last Seen** | `=this.LastSeen` |

# **`=this.Name`**

> [!military]- `=this.Name` Details
> `=this.Content`