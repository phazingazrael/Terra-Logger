
# Hub
> [!cards|7]
> **[[📝 Session Note Database| Session Notes]]**
> ![[SessionNotes.png]]
>
> **[[🎊Party Database| Parties]]**
> ![[Parties.png]]
> 
> **[[🧙‍♂️ Player Database| Players]]**
> ![[Players.png]]
> 
> **[[🧞‍♀️ Deity Database| Deities]]**
> ![[Deities.png]]
> 
> **[[👨‍👩‍👧‍👦 NPC Database| NPCs]]**
> ![[NPCs.png]]
> 
> **[[🔰 Group Database| Groups]]**
> ![[Groups.png]]
> 
> **[[🗺️ Country Database| Kingdoms]]**
> ![[Kingdoms.png]]
> 
> **[[🌁 City Database| Cities]]**
> ![[Settlements.png]]
> 
> **[[🏰 Landmark Database| Landmarks]]**
> ![[Landmarks.png]]
> 
> **[[❓ POI Database| Points of Interest]]**
> ![[POIs.png]]
>
> **[[💲 Shop & Service Database| Shops & Services]]**
> ![[ShopsServices.png]]
>
> **[[📕 Literature Database| Literature]]**
> ![[Literature.png]]
>
> **[[✉️ Letter Database| Letters]]**
> ![[Letters.png]]
> 
> **[[❗ Quest Database| Quests]]**
> ![[Quests.png]]
> 

## To Do
> [!column|2 no-title]
>> [!metadata] Short Term
>> - Item 1
>
>
>> [!metadata] Long Term
>> - Item 1
>
>
