---
BANNER: "[[NotesMain-Banner.jpg|-100]]"
---

```base
filters:
  and:
    - file.inFolder("World/16. Notes")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Type
      - tags
    columnSize:
      note.Name: 141
      note.Type: 226
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```