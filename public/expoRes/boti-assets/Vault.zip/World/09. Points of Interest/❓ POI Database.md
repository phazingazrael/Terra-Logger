---
BANNER: "[[POI-Banner.jpg]]"
---

```base
filters:
  and:
    - file.inFolder("World/09. Points of Interest")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Category
      - Type
      - Features
      - Owner
      - Established
      - Groups
      - ParentArea
      - Secrets
      - Services
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```