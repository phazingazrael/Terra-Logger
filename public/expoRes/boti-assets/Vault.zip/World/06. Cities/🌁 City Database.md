---
BANNER: "[[City-Banner.jpg|150]]"
---

```base
filters:
  and:
    - file.inFolder("World/06. Cities")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Pronounced
      - Type
      - Country
      - Features
      - GovtType
      - Leaders
      - Rulers
      - Population
      - Theme
      - tags
      - Imports
      - Exports
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```