---
BANNER: "[[Country-Banner.png|145]]"
---

```base
filters:
  and:
    - file.inFolder("World/04. Countries")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Pronounced
      - GovtType
      - Leaders
      - PlanetPlane
      - Rulers
      - Theme
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```