---
BANNER: "[[ShopsServices-Banner.jpg|100]]"
---

```base
filters:
  and:
    - file.inFolder("World/10. Shops & Services")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - AffiliatedGroup
      - Type
      - Location
      - Owners
      - Staff
      - Pronounced
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```