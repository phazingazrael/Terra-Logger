---
BANNER: "[[Group-Banner.jpg|100]]"
---
	
```base
filters:
  and:
    - file.inFolder("World/12. Groups")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Pronounced
      - Name
      - Type
      - Location
      - HQ
      - AssociatedReligion
      - Alignment
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```