---
BANNER: "[[Landmark-Banner.jpg|150]]"
---

```base
filters:
  and:
    - file.inFolder("World/08. Landmarks")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Pronounced
      - Country
      - Type
      - Owners
      - Staff
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```