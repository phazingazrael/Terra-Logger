---
BANNER: "[[LoreMain-Banner.jpg|-150]]"
---

```base
filters:
  and:
    - file.inFolder("World/01. Lore")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Type
      - Name
      - tags
    sort: []
    columnSize:
      note.Type: 163
      note.Name: 226
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```