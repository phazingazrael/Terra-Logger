---
BANNER: "[[Area-Banner.jpg|200]]"
---

```base
filters:
  and:
    - file.inFolder("World/05. Areas")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Type
      - Category
      - Climate
      - ConnectedAreas
      - Control
      - Encounters
      - Hazards
      - Landmarks
      - ParentRegion
      - Resources
      - Settlements
      - Terrain
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```