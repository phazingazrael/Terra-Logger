---
BANNER: "[[Deity-Banner.jpg|250]]"
---

```base
filters:
  and:
    - file.inFolder("World/02. Deities")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Type
      - Category
      - Domains
      - Clergy
      - HolyDays
      - HomePlane
      - Pantheon
      - Symbols
      - Titles
      - Worshippers
      - AssociatedGroups
      - Alignment
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```