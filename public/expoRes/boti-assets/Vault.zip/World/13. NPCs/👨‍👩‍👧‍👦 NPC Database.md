---
BANNER: "[[NPC-Banner.jpg]]"
---

```base
filters:
  and:
    - file.inFolder("World/13. NPCs")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Pronounced
      - Pronouns
      - Occupation
      - Location
      - Gender
      - Condition
      - Alignment
      - Ancestry
      - OwnedLocations
      - AssociatedGroup
      - AssociatedReligion
      - Heritage
      - Sexuality
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```