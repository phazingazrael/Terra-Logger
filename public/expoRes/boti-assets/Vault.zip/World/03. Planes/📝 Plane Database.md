---
BANNER: "[[Plane-Banner.jpg]]"
---

```base
filters:
  and:
    - file.inFolder("World/03. Planes")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Type
      - Category
      - AccessMethods
      - ConnectedPlanes
      - Traits
      - Inhabitants
      - RulingEntities
      - Hazards
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```