---
BANNER: "[[District-Banner.jpg|-150]]"
---

```base
filters:
  and:
    - file.inFolder("World/07. Districts")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - City
      - Type
      - Category
      - Culture
      - Demographics
      - Economy
      - Government
      - Landmarks
      - Groups
      - POIs
      - Population
      - Shops
      - Safety
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```