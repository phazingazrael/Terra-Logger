---
BANNER: "[[Literature-Banner.jpg|-150]]"
---

```base
filters:
  and:
    - file.inFolder("World/14. Literature")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Category
      - Genre
      - Name
      - Author
      - Type
      - DateWritten
      - Condition
      - Copies
      - KnownHolders
      - Language
      - Origin
      - Scribe
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```