---
BANNER: "[[Party-Banner.jpg|200]]"
---
```base
filters:
  and:
    - file.inFolder("World/00. Parties/0. Party Hubs")
    - and:
	    - file.hasProperty("Name")
views:
  - type: cards
    name: Cards
    order:
      - file.name
      - Name
      - Players
      - Leader
      - LevelRange
      - CurrentLocation
    limit: 50
  - type: table
    name: Table
    order:
      - file.name
      - NoteIcon
      - Type
      - Status
      - Players
      - Leader
      - LastSession
      - Holdings
      - SideQuests
      - SessionCount
      - ServiceRequests
      - Resources
      - Pronounced
      - ActiveQuests
      - aliases
      - AverageLevel
      - Cohorts
      - CurrentLocation
      - Goals
      - Funds
      - LevelRange
      - NPCAllies
      - tags
      - Theme
      - Vehicles
      - Base
    sort: []

```