---
BANNER: "[[ServiceRequest-Banner.jpg|300]]"
---

```base
filters:
  and:
    - file.inFolder("World/00. Parties/4. Service Request")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Category
      - Level
      - Status
      - GivenBy
      - Location
      - Deadline
      - Started
      - Completed
      - Difficulty
      - Urgency
      - Rewards
      - tags
    sort:
      - property: file.name
        direction: ASC

```