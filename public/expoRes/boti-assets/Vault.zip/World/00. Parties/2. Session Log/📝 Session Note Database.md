---
BANNER: "[[SesionLogs-Banner.jpg|150]]"
---

```base
filters:
  and:
    - file.inFolder("World/00. Parties/2. Session Log")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.basename
      - Name
      - Party
      - tags
      - Type
    columnSize:
      note.Name: 210
      note.Party: 217
      note.tags: 213

```