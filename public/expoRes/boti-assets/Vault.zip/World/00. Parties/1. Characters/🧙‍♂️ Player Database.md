---
BANNER: "[[Player-Banner.jpg|200]]"
---

```base
filters:
  and:
    - file.inFolder("World/00. Parties/1. Characters")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    order:
      - file.name
      - Name
      - Gender
      - Level
      - Class
      - Subclass
      - Background
      - Alignment
      - Deity
      - Size
      - STR
      - DEX
      - CON
      - INT
      - WIS
      - CHA
      - AC
      - HP
      - Initiative
      - Perception
      - Speed
      - Speeds
      - Ancestry
      - Heritage
      - Condition
      - Occupation
      - Aliases
      - AssociatedGroup
      - AssociatedReligion
      - Pronouns
      - PlayedBy
      - Party
      - Location
      - tags
    sort: []
    limit: 50
  - type: cards
    name: Cards
    order:
      - file.name
      - Name
      - Class
      - Subclass
      - Level

```