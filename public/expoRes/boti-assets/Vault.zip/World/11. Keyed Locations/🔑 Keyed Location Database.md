---
BANNER: "[[KeyedLocation-Banner.jpg|-100]]"
---

```base
filters:
  and:
    - file.inFolder("World/11. Keyed Locations")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Type
      - Category
      - Connections
      - Environment
      - Features
      - Hazards
      - Inhabitants
      - Key
      - ParentMap
      - Secrets
      - Treasures
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```