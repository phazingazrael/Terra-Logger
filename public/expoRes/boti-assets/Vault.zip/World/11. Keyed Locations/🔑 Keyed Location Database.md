---
BANNER: "[[KeyedLocation-Banner.jpg|-100]]"
---

```base
filters:
  and:
    - file.inFolder("World/11. Keyed Locations")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    order:
      - file.name
      - Name
      - Type
      - Category
      - Connections
      - Environment
      - Features
      - Hazards
      - Inhabitants
      - Key
      - ParentMap
      - Secrets
      - Treasures
      - tags
    sort:
      - property: Treasures
        direction: ASC
    limit: 50
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```