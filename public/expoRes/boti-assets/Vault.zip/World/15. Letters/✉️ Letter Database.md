---
BANNER: "[[Letter-Banner.jpg|200]]"
---

```base
filters:
  and:
    - file.inFolder("World/15. Letters")
    - and:
        - file.hasProperty("Name")
views:
  - type: table
    name: Table
    limit: 50
    order:
      - file.name
      - Name
      - Sender
      - Recipient
      - Status
      - Type
      - tags
  - type: cards
    name: Cards
    order:
      - file.name
      - Name

```