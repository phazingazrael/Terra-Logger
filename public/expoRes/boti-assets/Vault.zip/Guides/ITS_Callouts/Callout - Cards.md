# Cards Callout
> Simple columns to display images along with text. For more complex usage, use the [[Callout - Columns|Columns Callout]].

> [!note]  Use Image Adjustments functionality to control the images sizing

- Blank Line `>` separated
- `**Bold**` syntax will center text and and a background color 
	- (no background color for dataview tables)

| Adjustment    | Description                                        |
| ------------- | -------------------------------------------------- |
| `2`, `4`, `5` | Change number of columns; 3 is default             |
| `dataview`    | Style dataview table and lists as cards            |
| `dvl`         | Style dataview list                                |
| `no-strong`   | Undo strong's center and background color styling  |
| `notion`      | Style cards in the style of Notion's gallery cards |

---
## Examples

**External and Internal Images:**
```markdown
> [!cards]
> **[[Link]]**
> ![Image link|sban htiny ctr](https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> 
> **[[Link]]**
> ![[Image Link.png|sban htiny ctr]]
```

**Add More Columns:**
```markdown
> [!cards|4]
> **[[Link]]**
> ![Image link|sban htiny ctr](https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> 
> **[[Link]]**
> ![[Image Link.png|sban htiny ctr]]
> 
> **[[Link]]**
> ![Image link|sban htiny ctr](https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> 
> **[[Link]]**
> ![[Image Link.png|sban htiny ctr]]
```

**Style Dataview Table:**
````markdown
> [!cards|dataview]
> ```dataview
> TABLE WITHOUT ID
> 	"![|sban cover hmicro](" + image + ")" as Image,
> 	"**"+ file.link + "**" AS "Column Name",
> 	file.mtime AS "Modified"
> FROM "folder"
> SORT file.name asc
> LIMIT 10
> ```

> [!cards|dvl no-strong]
> ```dataview
> LIST WITHOUT ID file.link + "<br>" + file.mtime
> FROM "folder"
> SORT file.name asc
> LIMIT 10
> ```
````

## Live Example
> [!cards]
> **[By Thibault Penin](https://unsplash.com/photos/AWOl7qqsffM)**
> ![|sban htiny ctr](https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> 
> **[By Clint Bustrillos](https://unsplash.com/photos/X-A-LJVAhzk)**
> ![|sban htiny ctr+p+cb](https://images.unsplash.com/photo-1549056572-75914d5d5fd4?ixid=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> 
> **[By Jiawei Zhao](https://unsplash.com/photos/W-ypTC6R7_k)**
> ![tuxedo cat in brown cardboard box|sban htiny ctr p+b](https://images.unsplash.com/photo-1615678857339-4e7e51ce22db?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTl8fGJveGVzfGVufDB8fDB8fA%3D%3D&w=1000&q=80)
> 
> ![|sban htiny ctr p+t](https://images.unsplash.com/photo-1539375665275-f9de415ef9ac?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> **[By Guillaume TECHER](https://unsplash.com/photos/Jm9P0mDPo6A)**
> 
> ![|sban htiny ctr p+b](https://images.unsplash.com/photo-1628832307345-7404b47f1751?ixid=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> **[By Supratik Deshmukh](https://unsplash.com/photos/iO0I6-mhDEY)**
> 
> ![red cinema chair|sban htiny ctr p+b](https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80)
> **[By Felix Mooneeram](https://unsplash.com/photos/evlkOfkQ5rE)**

> [!cards|notion wmed]
> **[By Thibault Penin](https://unsplash.com/photos/AWOl7qqsffM)**
> Extra text
> ![|sban htiny ctr](https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> 
> **[By Clint Bustrillos](https://unsplash.com/photos/X-A-LJVAhzk)**
> ![|sban htiny ctr+p+cb](https://images.unsplash.com/photo-1549056572-75914d5d5fd4?ixid=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> 
> **[By Jiawei Zhao](https://unsplash.com/photos/W-ypTC6R7_k)**
> ![tuxedo cat in brown cardboard box|sban htiny ctr p+b](https://images.unsplash.com/photo-1615678857339-4e7e51ce22db?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTl8fGJveGVzfGVufDB8fDB8fA%3D%3D&w=1000&q=80)
> 
> ![|sban htiny ctr p+t](https://images.unsplash.com/photo-1539375665275-f9de415ef9ac?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> **[By Guillaume TECHER](https://unsplash.com/photos/Jm9P0mDPo6A)**
> 
> ![|sban htiny ctr p+b](https://images.unsplash.com/photo-1628832307345-7404b47f1751?ixid=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200)
> **[By Supratik Deshmukh](https://unsplash.com/photos/iO0I6-mhDEY)**
> 
> ![red cinema chair|sban htiny ctr p+b](https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80)
> **[By Felix Mooneeram](https://unsplash.com/photos/evlkOfkQ5rE)**
