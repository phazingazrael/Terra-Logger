# Callout Timeline

| Adjustment | Description |
| --- | --- |
| `t-l` | Timeline callout left side |
| `t-r` | Timeline callout right side |
|  |  |
| `t-1` to `t-10` | Add some spacing above the timeline callout to simulate how close events are in time |

```markdown
> [!timeline|t-l] **Title** _Subtitle_
> Left aligned timeline piece

> [!timeline|t-r t-4] **Title** *Subtitle*
> Right aligned timeline piece

> [!timeline|t-r t-10] **Title** *Subtitle*
> Spaced timeline piece
```

## Live Example

> [!timeline|t-l] **Title** _Subtitle_
> Left aligned timeline piece

> [!timeline|t-r]+ **Title** _Subtitle_
> Right aligned timeline piece, collapsible

> [!timeline|t-r t-4] **Title** *Subtitle*
> Right aligned timeline piece: t-4 spacing

> [!timeline|t-r t-10] **Title** *Subtitle*
> Spaced timeline piece: t-10 Spacing
