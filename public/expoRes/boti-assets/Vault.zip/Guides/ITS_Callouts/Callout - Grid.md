# Callout Image Grids

| | |
| --- | --- |
| `[!grid]` | Best type for **internally linked** images |
| <code>[!grid\|masonry]</code> | Best type for **externally linked** images |

## Example

```markdown
> [!grid]
> ![[Internal Image.png]]
> ![[Internal Image 2.png]]
>
> ![[Internal Image 3 on New Row.png]]
```

```markdown
> [!grid|masonry]
> ![External Image 1](https://www.dmuth.org/wp-content/uploads/2021/03/obsidian-logo.png)
> ![External Image 2](https://www.dmuth.org/wp-content/uploads/2021/03/obsidian-logo.png)
> 
> ![External Image 3 on New Row](https://raw.githubusercontent.com/SlRvb/Obsidian--ITS-Theme/main/Images/Callout-Grid.png)
> ![External Image 4](https://obsidian.md/images/obsidian-logo-gradient.svg)
```