# Callout Asides

| Adjustment | Description |
| --- | --- |
| `show-title` | Brings back callout title for Asides |
| `clean` | Remove Aside styling |
| `tufte` | Tufte Aside styling (WIP, somewhat buggy) |
| `left` | Move aside left |
| `right` | Move aside right |

## Example

```markdown
> [!aside|clean right]
> Removes styling from aside

> [!aside|tufte]+ 
> Tufte styled aside callout

> [!aside|tufte title]
> Show callout title for asides
```

## Live Example

> [!aside]
> Basic Aside on right side

> [!aside|left]
> Basic Aside on left side

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sit amet metus sed dui dapibus ullamcorper. Pellentesque dictum est tortor, id tempus orci dignissim quis. Morbi sagittis vitae lectus nec volutpat. Phasellus quis ex consectetur, dictum nibh at, commodo nisi. 

> [!aside|title]+ Collapsed Aside Styling
> Aside styling for collapsed asides

> [!aside|left]-
> Hidden aside

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sit amet metus sed dui dapibus ullamcorper. Pellentesque dictum est tortor, id tempus orci dignissim quis. Morbi sagittis vitae lectus nec volutpat. Phasellus quis ex consectetur, dictum nibh at, commodo nisi. 

> [!aside|tufte title]+ Tufte Style
> Aside styling for collapsed asides

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sit amet metus sed dui dapibus ullamcorper. Pellentesque dictum est tortor, id tempus orci dignissim quis. Morbi sagittis vitae lectus nec volutpat. Phasellus quis ex consectetur, dictum nibh at, commodo nisi. 

%%
![](https://cdn.discordapp.com/attachments/855181471643861002/977756711618228325/Obsidian_FXcbH8YskB.gif) 
%%