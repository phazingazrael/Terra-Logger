# Callout Infoboxes

## Attributes

| Attribute   | Description                       |
| ----------- | --------------------------------- |
| `wikipedia` | Style inner tables like wikipedia |

---
## Examples

```markdown
> [!infobox]
> # Name
> ![[Image.png|cover hsmall]]
> ###### Stats
> | Type | Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> 
> ##### Stats 2
> | Type | Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
```

```markdown
> [!infobox]+ Collapsible Infobox
> # Name
> ![[Image.png|cover hsmall]]
> ###### Stats
> | Type | Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> 
> ###### Stats 2
> | Type | Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
```

```markdown
> [!infobox|left]
> # Name
> ![[Image.png|cover hsmall]]
> ###### Stats
> | Type | Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> 
> ###### Stats 2
> | Type | Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
```

```markdown
> [!infobox|left wikipedia]+
> # Heading
> ![[Image.png]]
> ###### Heading 6
> | Table Header |  Table Header |
> | ---- | --- |
> | Test | Testing |
> | Test | Testing |
> 
> # Heading 1
> - Bullet list
> 	- Testing
> 	- Testing
> - Testing
```

## Live Examples

> [!infobox]+
> # Default
> ![[PlaceholderImage.png]]
> ###### Heading 6
> | Table Header |  Table Header |
> | ---- | --- |
> | Test | Testing |
> | Test | Testing |
> 
> # Heading 1
> - Bullet list
> 	- Testing
> 	- Testing
> - Testing

> [!infobox|left wikipedia]+
> # Left Callout
> # Wikipedia Styling
> ![[PlaceholderImage.png]]
> ###### Heading 6
> | Table Header |  Table Header |
> | ---- | --- |
> | Test | Testing |
> | Test | Testing |
> 
> # Heading 1
> - Bullet list
> 	- Testing
> 	- Testing
> - Testing

---