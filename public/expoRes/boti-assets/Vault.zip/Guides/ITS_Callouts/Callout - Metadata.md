# Callout Metadata

> [!metadata]
> **Bold Text** Regular Text
> **Dataview Inline Field**:: Value

| Attribute | Description |
| --- | --- |
| <code>\|i-at</code> | ITS `<i>` styling |
| `no-strong`, `no-str` | Undo strong color styling |

## Examples

`i-at`

> [!metadata|i-at]
> **Dataview Inline Field**:: Value

> [!metadata|i-at]+
> Collapsible
> **Dataview Inline Field**:: Value

> [!metadata|i-at]- 
> Collapsed
> **Dataview Inline Field**:: Value

> [!metadata|no-str]
> **Dataview Inline Field**:: Value