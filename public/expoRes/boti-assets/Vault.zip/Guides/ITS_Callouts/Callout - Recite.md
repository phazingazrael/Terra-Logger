# Recite Callout

## Examples
```
>[!recite]
>Lorem Ipsum Dolor Sit Amet

>[!recite] Announce
>Lorem Ipsum Dolor Sit Amet
```
## Live Examples 
>[!recite]
>Lorem Ipsum Dolor Sit Amet

>[!recite] Announce
>Lorem Ipsum Dolor Sit Amet