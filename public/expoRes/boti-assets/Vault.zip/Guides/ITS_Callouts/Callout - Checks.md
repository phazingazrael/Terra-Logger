# Checks Callout

> [!checks]
> 
> - **Physical**
> 	- Strength
> 	- [ ] %%  %%
> 	- [ ] %%  %%
> 	- [ ] %%  %%
> 	- [ ] %%  %%
> 	- [ ] %%  %%
> - 
> 	- Dexterity
> 	- [ ] %%  %%
> 	- [ ] %%  %%
> 	- [x] %%  %%
> 	- [x] %%  %%
> 	- [x] %%  %%
> - 
> 	- Stamina
> 	- [x] %%  %%
> 	- [x] %%  %%
> 	- [x] %%  %%
> 	- [ ] %%  %%
> 	- [ ] %%  %%

> [!checks] 
> - **Death Saves**
>	- ❌
>	- [ ] 
>	- [ ] 
>	- [ ] 
>	- ✔
>	- [ ] 
>	- [ ] 
>	- [ ] 

> [!checks]
> - **GROUP**
> 	- Next to checkboxes
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> - **New Row**
> 	- Description
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [x] %% %%
> 	- [x] %% %%
> 	- [x] %% %%
> - 
> 	- Empty root bullet is necessary to group bullets together
> 	- [x] %% %%
> 	- [x] %% %%
> 	- [x] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%


# Syntax

```yaml
> [!checks]
> - **GROUP**
> 	- Next to checkboxes
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> - **New Row**
> 	- Description
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [x] %% %%
> 	- [x] %% %%
> 	- [x] %% %%
> - 
> 	- Empty root bullet is necessary to group bullets together
> 	- [x] %% %%
> 	- [x] %% %%
> 	- [x] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

```