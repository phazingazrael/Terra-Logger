# Callout Quote

| Metadata |                                        |
| -------- | -------------------------------------- |
| `author` | Put author name in bottom right corner |
| `mark`   | Add Quote mark on right side           |

# Examples

```markdown
> [!quote|author] Quote Author Here
> Blockquote text here

> [!quote|mark] Author
> Quote with Mark

> [!Quote|author mark] Quote Author Here <br>New Line stuff here
> Blockquote text here
```

> [!quote|author] Author
> Quote

> [!quote|mark] Author
> Quote with Mark

> [!Quote|author mark] Quote Author Here <br>New Line stuff here
> Quote & mark callout