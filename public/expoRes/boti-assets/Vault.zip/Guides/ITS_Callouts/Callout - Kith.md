# Callout Kith

```markdown
> [!kith|relationship] **Character Name** _Subtitle/Brief Relationship Description_
```

- Relationship Types
	- `family`
	- `friend`
	- `romantic`
	- `antagonist`

> [!kith] **Name** _Subtitle/Brief Relationship Description_

> [!kith|family] Family

> [!kith|friend] Friend

> [!kith|antagonist] Antagonist

> [!kith|romantic] Romantic