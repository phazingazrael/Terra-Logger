  
# Statblocks Callout
> Style information as a statblock

- [[Image Adjustments]] used for the image styling/placement.
- [[Callout - Checks|Checks Callout]] used for death saves check section.


| Adjustment | Description                                                                  |
| ---------- | ---------------------------------------------------------------------------- |
| columns    | Split statblock into columns. `1-9`, default 2. Needs `[!blank]` subcallouts |
| full       | Make the statblock fill the whole page                                       |


> [!statblocks]
> ![Char Image| right circle htiny wtiny lp]()
> 
> # Name
> > Description
> *Basics*
> *Basics*
> 
> ---
| HP | AC | Initiative |
|:---:|:---:|:---:|
| # | # | # |
>
| STR | DEX | CON | INT | WIS | CHA |  |
|:---:|:---:|:---:|:---:|:---:|:---:|:--- |
| # | # | # | # | # | # |  |
| # | # | # | # | # | # | **Mod** |
| # | # | # | # | # | # | **Sav** |
> 
|  |  |
| ---:|:--- |
| **Speed** |  |
| **Passive Perception (WIS)** |  |
| **Proficiency Bonus** |  |
| **Darkvision** |  |
>
> ---
>> [!checks|no-t] 
>> - **Death Saves**
>>	- ❌
>>	- [ ] 
>>	- [ ] 
>>	- [ ] 
>>	- ✔
>>	- [ ] 
>>	- [ ] 
>>	- [ ] 
>
> ###### Traits
|  |  |
| --- | --- |
| **Class** | Description |
| **Feats** | Description |

> [!statblocks|columns]
> 
>> [!blank]  
>> ![Char Image|right cover htiny wtiny circle lp]()
>> # Name
>> > Description
>> 
>> *Basics*
>> 
>> ---
| HP | AC | Initiative |
|:---:|:---:|:---:|
| | | |
>>
| STR | DEX | CON | INT | WIS | CHA |  |
|:---:|:---:|:---:|:---:|:---:|:---:|:--- |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  | **Mod** |
|  |  |  |  |  |  | **Sav** |
>>
|  |  |
| ---:|:--- |
| **Speed** |  |
| **Passive Perception (WIS)** |  |
| **Proficiency Bonus** |  |
| **Darkvision** |  |
>> 
>> ---
>> 
>>> [!checks|no-t] 
>>> - 
>>>	- **Spell Slots**
>>>	- [ ] 
>>>	- [ ] 
>>> - **Death Saves**
>>>	- ❌
>>>	- [ ] 
>>>	- [ ] 
>>>	- [ ] 
>>>	- ✔
>>>	- [ ] 
>>>	- [ ] 
>>>	- [ ] 
>> 
> 
> 
>> [!blank]
>> ## Traits
|  |  |
| --- | --- |
| **Trait** | Description |
>> 
>> ## Feats
>> **Feat**
>> Description
>> 
>> **Feat**
>> Description


# Syntax

```yaml
> [!statblocks]
> ![Char Image|cover right circle htiny wtiny lp]()
> 
> # Name
> > Description
> *Basics*
> *Basics*
> 
> ---
| HP | AC | Initiative |
|:---:|:---:|:---:|
| | | |
>
| STR | DEX | CON | INT | WIS | CHA |  |
|:---:|:---:|:---:|:---:|:---:|:---:|:--- |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  | **Mod** |
|  |  |  |  |  |  | **Sav** |
> 
|  |  |
| ---:|:--- |
| **Speed** |  |
| **Passive Perception (WIS)** |  |
| **Proficiency Bonus** |  |
| **Darkvision** |  |
>
> ---
>> [!checks|no-t] 
>> - **Death Saves**
>>	- ❌
>>	- [ ] 
>>	- [ ] 
>>	- [ ] 
>>	- ✔
>>	- [ ] 
>>	- [ ] 
>>	- [ ] 
>
> ###### Traits
| | |
| --- | --- |
| **Class** | |
| **.** | |
| **Racial Traits** | |
| **Feats** | |
```

**Columns adjustment option**
```yaml
> [!statblocks|columns]
> 
>> [!blank]  
>> ![Char Image|right cover htiny wtiny circle lp]()
>> # Name
>> > Description
>> 
>> *Basics*
>> 
>> ---
| HP | AC | Initiative |
|:---:|:---:|:---:|
| | | |
>>
| STR | DEX | CON | INT | WIS | CHA |  |
|:---:|:---:|:---:|:---:|:---:|:---:|:--- |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  | **Mod** |
|  |  |  |  |  |  | **Sav** |
>>
|  |  |
| ---:|:--- |
| **Speed** |  |
| **Passive Perception (WIS)** |  |
| **Proficiency Bonus** |  |
| **Darkvision** |  |
>> 
>> ---
>> 
>>> [!checks|no-t] 
>>> - 
>>>	- **Spell Slots**
>>>	- [ ] 
>>>	- [ ] 
>>> - **Death Saves**
>>>	- ❌
>>>	- [ ] 
>>>	- [ ] 
>>>	- [ ] 
>>>	- ✔
>>>	- [ ] 
>>>	- [ ] 
>>>	- [ ] 
>> 
> 
> 
>> [!blank]
>> ## Traits
| | |
| --- | --- |
>> 
>> ## Feats
>> 
>> **Feat**
>> Description
>> 
>> **Feat**
>> Description
```