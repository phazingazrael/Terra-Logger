# Callout Kanban

```markdown
> [!kanban]+
> - [[Link|Lane 1 Title]]
> 	- ![[Image.png]]
> 	- [[Link|Card]]
> - [[Link|Lane 2 Title]]
> 	![[Image without background card styling.png]]
> 	- [[Link|Card]]
> - Text
> 	- [ ] Text
```

## Live Example

> [!kanban]+
> - Lane 1 Title
> 	- Card
> - Lane 2 Title
> 	- Card
> - Text
> 	- [ ] Text
> 	- [ ] Text