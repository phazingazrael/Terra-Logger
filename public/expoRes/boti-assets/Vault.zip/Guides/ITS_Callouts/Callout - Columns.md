# Callout Columns
> Display elements within the callout as columns


| Adjustment    | Description                                                                               |
| ------------- | ----------------------------------------------------------------------------------------- |
| `flex`        | Wrap column on smaller width screens                                                      |
| `3`, `4`      | Add more columns; Default is 2                                                            |
| `dataview`    | Styles dataview `LIST` & `TABLE` into columns <br>(column numbers work with this as well) |
| `list`        | Make bullet lists into columns                                                            |
| `list-x`      | Bullet list columns are horizontally ordered rather than vertically                       |
| `slim-margin` | Reduce gap between columns (Abbr. `s-mg`)                                                 |

- Separated by a blank `>`
	- Must be the same level as the root callout to properly separate

> [!important|bg-c-red] *Must use sub-callouts* in order for columns callout to work properly
> It might work without subcallouts but it is not consistent and it is not the way this callout is designed to function. 
> 
> If you're not using subcallouts and issues are occurring, wrap your stuff in a subcallout and it should be fixed

---
## Examples
```markdown
> [!column]
>> [!info] Column 1
>> - Use another callout for columns
>
>> [!note] Column 2
>> Need that singular blockquote `>` as separation between columns
```

**Clean/hidden Subcallout Styling**
```markdown
> [!column]
>> [!blank] Column 1
>> - Use another callout for columns
>
>> [!blank] Column 2
>> Need that singular blockquote `>` as separation between columns
>
>> [!blank] Column 3
>> Need that singular blockquote `>` as separation between columns
```

**Flex Sizing**
```markdown
> [!column|flex 3]
>> [!info|no-t] 
>> Column 1, no title
>
>> [!important]+ Current Topics
>> Column 2
```

**Dataview Columns**
````markdown
> [!column|dataview 3] 3 Columns for Dataview List
> ```dataview
> LIST file.mday
> FROM ""
> LIMIT 20
> ```
````

**Columns for Bullet Lists**
```markdown
> [!column|list] Columns for regular lists only
> - List Item
> 	- Sub list item
> - List Item
> - List Item
> 	- Sub list item
> 	- Sub list item
> - List Item
> - List Item
> - List Item
> - List Item
> 	- Sub list item
> 	- Sub list item
> 	- Sub list item
> - List Item
> - List Item
> - List Item
```

## Live Examples

> [!column]
>> [!info] Column 1
>> - Use another callout for columns
>
>> [!note] Column 2
>> Need that singular blockquote `>` as separation between columns

---

> [!column|3] Column with !blank callouts
>> [!blank] Column 1
>> - Use another callout for columns
>
>> [!blank] Column 2
>> Need that singular blockquote `>` as separation between columns
>
>> [!blank] Column 3
>> Need that singular blockquote `>` as separation between columns

---

> [!column|list] `list` Columns for regular lists only
> - List Item 1
> 	- Sub list item
> - List Item 2
> - List Item 3
> 	- Sub list item
> 	- Sub list item
> - List Item 4
> 
> - List Item
> - List Item
> - List Item
> 	- Sub list item
> 	- Sub list item
> 	- Sub list item
> - List Item
> - List Item
> - List Item

> [!column|list-x 3] `list-x`
> - List Item 1
> 	- Sub list item
> - List Item 2
> - List Item 3
> 	- Sub list item
> 	- Sub list item
> - List Item 4
> - List Item 5
> - List Item 6 
> - List Item 7
> 	- Sub list item
> 	- Sub list item
> 	- Sub list item
> - List Item 8
> - List Item 9
> - List Item 10


---
![[Obsidian_90Ehg2COYn.png]]