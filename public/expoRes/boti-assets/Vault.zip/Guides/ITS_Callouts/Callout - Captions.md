# Callout Captions

## Examples

```markdown
> [!caption|left] Floats to the left
> ![[Image.png]]
> Caption text here

> [!caption|right] Floats to the right
> ![[Image.png]]
> Caption text here
```

```markdown
> [!caption|sban] Full width caption sizing
> Caption text can be up here too
> ![[Image.png]]

> [!caption|right wsmall] Small caption sizing
> ![[Image.png]]
```

## Live Example

> [!caption|left] Auto floats to the right
> ![[PlaceholderImage.png|150]]
> Caption text here

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sit amet metus sed dui dapibus ullamcorper. Pellentesque dictum est tortor, id tempus orci dignissim quis. Morbi sagittis vitae lectus nec volutpat. Phasellus quis ex consectetur, dictum nibh at, commodo nisi. 

> [!caption|right]
> ![[PlaceholderImage.png|150]]
> Caption text: 
> SlRvb Logo

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sit amet metus sed dui dapibus ullamcorper. Pellentesque dictum est tortor, id tempus orci dignissim quis. Morbi sagittis vitae lectus nec volutpat. Phasellus quis ex consectetur, dictum nibh at, commodo nisi. 

> [!caption|sban] Full width caption sizing
> Caption text can be up here too
> ![[PlaceholderImage.png]]