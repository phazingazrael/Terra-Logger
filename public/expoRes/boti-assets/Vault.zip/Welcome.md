# Welcome to the Terra-Logger Vault Export

> [!example|clean] Table Of Contents
> - [[#Welcome to the Terra-Logger Vault Export|Introduction]]
> - [[#Vault Structure Overview]]
> - [[#Template Conventions]]
> - [[#Getting Started]]
> - [[#Credits]]

> [!overview] Introduction  
> This vault contains a structured network of templates, databases, and assets for organizing everything from gods and planes to quests, NPCs, and letters.  
>  
>  Your map details will be placed into the "World" folder, and an additional map file is placed at the root of this folder along with the map image.
>  
> You can freely delete or modify this file — it exists only as a guide to help you get started.

## Vault Structure Overview
> [!map] Primary Layout  
> **Root Files**  
> - `⭐Hub.md` → Central navigation hub for quick access.  
> - `Credits.md` → Attribution and acknowledgments.  
> - `Welcome.md` → (This file) Vault introduction.  
>  
> **Guides** → Contains documentation and explanations for using callouts, templates, and system conventions.
>  
> **"Map"** → Core world and campaign data.  
> - Organized by topic: Parties, Lore, Deities, Planes, Countries, Areas, Cities, Districts, Landmarks, POIs, etc.  
> - Each folder contains a `Database.md` file that indexes entries within it.  
>  
> **z_Assets** → All media, banners, and hub images.  
> - `/Banners/`, `/Hub/`, and `/Misc/` for organized storage.  
>  
> **z_Templates** → All template files, sorted by category.  
>  - `Terra-Logger/`
> 	- `/economy/`, `/lore/`, `/notes/`, `/people/`, `/world/`  
> 	- Each includes standardized frontmatter and callout structures.

---

## Template Conventions
> [!notes] Standardization  
> Every template in **Terra-Logger** follows consistent design rules:
> - All files start with frontmatter containing `BANNER`, `Name`, and `tags`.  
> - Infoboxes use "=this.Name" for display (never "=this.file.name").  
> - Callouts follow categorized sections (e.g., `[!overview]`, `[!story]`, `[!Rumors]`, `[!Secrets]`).  
> - Each folder’s `Database.md` uses Obsidian Bases to display related entries.

---

## Getting Started
> [!misc] Tips for getting started
> 1. Open `⭐Hub.md` for navigation and quick links.  
> 2. Review `/Guides` to learn how to use included Callouts and review included Templates. 
> 3. Create new entries by copying a file from `/z_Templates/Terra-Logger/...` and updating 
>     its frontmatter, or use the default template functionality.  
> 4. Use banners from `/z_Assets/Banners/` to visually differentiate note types.  
> 5. Delete this `Welcome.md` file once you’re comfortable — it’s not required.

---

## Credits
For credits and acknowledgments please see the [[Credits]] File.
