# Credits:

**Vault Inspired by V1.0 of Bag of Tips Vault**: [Bag of Tips](https://ko-fi.com/bagoftips)

---
## Banners
**Country Banner Image**: [artandmusic909](https://pixabay.com/illustrations/golden-kingdom-elven-kingdom-fantasy-8164867/)
**Landmark Banner Image**: [Ron Baron](https://unsplash.com/photos/a-set-of-steps-leading-up-to-some-statues-YF86VTMn9r0)

### Banners under WotC Fan Content
 **[WotC Fan Content Policy](https://company.wizards.com/en/legal/fancontentpolicy)** 

 - **Adventure Banner Image**: Conqueror’s Foothold by [Emrah Elmasli](https://www.artstation.com/emrahelmasli)
 - **Area Banner Image**: Rampant Growth by [Jeff Miracola](https://jeffmiracola.com/)
 - **City Banner Image**: Selesnya Sanctuary (Variant) by [Ron Spears](https://ronspearsart.com/)
 - **Culture Banner Image**: Jodah, the Unifier by [Ryan Pancoast](https://www.ryanpancoast.com/)
 - **Deity Banner Image**: Vecna Token by [Irina Nordsol](https://nord-sol.com/)
 - **District Banner Image**: Baldur’s Gate by [Titus Lunter](https://tituslunter.com/)
 - **Group Banner Image**: Collected Company by  [Franz Vohwinkel](https://www.franz-vohwinkel.com/)
 - **Keyed Location Banner Image**: Botanical Plaza (Variant) by [Olga Tereshchenko](https://www.deviantart.com/olga-tereshenko)
 - **Letter Banner Image**: Dispatch Dispensary by [Ralph Horsley](https://www.ralphhorsley.co.uk/)
 - **Literature Banner Image**: The Underworld Cookbook by [Joe Slucher](https://www.joeslucher.com/)
 - **Lore "Main" Banner Image**: Island by [Adam Paquette](http://www.adampaquettemtg.com/)
 - **Lore Banner Image**: Wizard’s Spellbook By [Iris Compiet](https://iriscompiet.art/)
 - **Military Banner Image**: Invasion of New Phyrexia by [Chris Rallis](https://www.rallisart.com/)
 - **Notes "Main" Banner Image**: Pore Over the Pages by [Magali Villeneuve](https://bsky.app/profile/magalivilleneuve.bsky.social)
 - **NPC Banner Image**: Merry Bards by [Iris Compiet](https://iriscompiet.art/)
 - **Party Banner Image**: Secure the Wastes by [Scott Murphy](https://www.murphyillustration.com/)
 - **Plane Banner Image**: Serum Visions by [Jaime A. Zuverza](https://www.instagram.com/jaime_zu/)
 - **Player Banner Image**: Boundary Lands Ranger by [Pascal Quidault](https://www.artstation.com/pascalquidault)
 - **Points of Interest Banner Image**: Hedge Maze By [Andrew Mar](https://www.andrewkmar.com/)
 - **Quest Banner Image**: Tapestry of the Ages by [Yeong-Hao Han](https://www.artstation.com/fooyee)
 - **Religion Banner Image**: Mystic Meditation by [Howard Lyon](https://www.howardlyon.com/)
 - **Service Request Banner Image:** Mordenkainen by [Ryan Pancoast](https://www.ryanpancoast.com/)
 - **Session Notes/Logs Banner Image**: Archive Dragon by [Tyler Walpole](https://www.tylerwalpole.com/)
 - **Shops & Services Banner Image**: Merchant of the Vale by [John Severin Brassell](https://johnseverinbrassell.com/)
